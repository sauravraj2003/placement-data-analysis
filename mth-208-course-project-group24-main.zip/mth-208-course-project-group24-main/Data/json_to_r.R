library(jsonlite)
library(tibble)

setwd("/home/atulya/Desktop/MTH208/mth-208-course-project-group24/ShinyApp/g24")
# Example JSON object as a string
json_string <- '[
    {
        "Name": "Harshit Raj",
        "Roll No.": "200433",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Abhishek Shree",
        "Roll No.": "200028",
        "Company Name": "Qube Research & Technology",
        "Profile": "PIO-PPO",
        "Branch": "BS-ECO",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Somya Gupta",
        "Roll No.": "200993",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Manas Gupta",
        "Roll No.": "200554",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Agrim Pandey",
        "Roll No.": "200061",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-AE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Rishi Malhotra",
        "Roll No.": "200794",
        "Company Name": "Alvarez & Marsal",
        "Profile": "Associate",
        "Branch": "BT-ME",
        "ctc": "1830000.0",
        "companyID": "2108"
    },
    {
        "Name": "Parinay Chauhan",
        "Roll No.": "200667",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sunay Chhajed",
        "Roll No.": "19816876",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Product & Growth Analyst",
        "Branch": "DualB-ECO",
        "ctc": "1700000.0",
        "companyID": "2088"
    },
    {
        "Name": "Rashmi G R",
        "Roll No.": "200772",
        "Company Name": "chaabi",
        "Profile": "Software Development Engineer - I",
        "Branch": "BT-CSE",
        "ctc": "4500000.0",
        "companyID": "2145"
    },
    {
        "Name": "Shivangi Singh",
        "Roll No.": "200943",
        "Company Name": "App Orchid Inc",
        "Profile": "Data Sciecne / AI / ML",
        "Branch": "BS-CHM",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Vedant Dangi",
        "Roll No.": "201101",
        "Company Name": "Cubastion Consulting",
        "Profile": "Graduate Trainee Engineer",
        "Branch": "BT-MSE",
        "ctc": "600000.0",
        "companyID": "1752"
    },
    {
        "Name": "Arushi Garg",
        "Roll No.": "200193",
        "Company Name": "MasterCard",
        "Profile": "Data Engineer",
        "Branch": "BT-MSE",
        "ctc": "1200000.0",
        "companyID": "2190"
    },
    {
        "Name": "Harsh Ranjan",
        "Roll No.": "200417",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-CHE",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Priyanka Jalan",
        "Roll No.": "190649",
        "Company Name": "AlphaGrep Securities Private Limited",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ankit Choudhary",
        "Roll No.": "200135",
        "Company Name": "QuNu Labs Pvt Ltd",
        "Profile": "Software Engineer",
        "Branch": "BT-EE",
        "ctc": "1800000.0",
        "companyID": "2271"
    },
    {
        "Name": "Nishithaarsh",
        "Roll No.": "200647",
        "Company Name": "Indian Political Action Committee",
        "Profile": "Campaign Manager",
        "Branch": "BT-CE",
        "ctc": "1537000.0",
        "companyID": "2444"
    },
    {
        "Name": "Kaif",
        "Roll No.": "19817491",
        "Company Name": "Dolat Capital",
        "Profile": "Quantitative Strategist",
        "Branch": "DualA-PHY",
        "ctc": "2700000.0",
        "companyID": "2178"
    },
    {
        "Name": "Yashwant Mahajan",
        "Roll No.": "201156",
        "Company Name": "Dolat Capital",
        "Profile": "Quantitative Strategist",
        "Branch": "BT-EE",
        "ctc": "2700000.0",
        "companyID": "2178"
    },
    {
        "Name": "Satyam Kumar Roy",
        "Roll No.": "200895",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BS-MTH",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Shubh Bajaj",
        "Roll No.": "200963",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Software Development Engineer 1 (SDE 1)",
        "Branch": "BS-MTH",
        "ctc": "2053830.0",
        "companyID": "1837"
    },
    {
        "Name": "Shashvat Singham",
        "Roll No.": "200922",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BS-PHY",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Pratyush Gupta",
        "Roll No.": "200716",
        "Company Name": "EVERSANA",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Amit Songara",
        "Roll No.": "200112",
        "Company Name": "NPCI",
        "Profile": "IT Analyst",
        "Branch": "BT-EE",
        "ctc": "2006000.0",
        "companyID": "2186"
    },
    {
        "Name": "Udit Prasad",
        "Roll No.": "201055",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-CSE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Hisham Hadi T",
        "Roll No.": "200448",
        "Company Name": "Google India",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Hariom Vediya",
        "Roll No.": "200402",
        "Company Name": "Rosy Blue (India) Pvt. Ltd.",
        "Profile": "Engineering Trainee",
        "Branch": "BT-CHE",
        "ctc": "1300000.0",
        "companyID": "2339"
    },
    {
        "Name": "Mansi Pradip Koshti",
        "Roll No.": "22103031",
        "Company Name": "Aereo",
        "Profile": "Geospatial Data Analyst & Developer",
        "Branch": "MT-CE",
        "ctc": "1266666.6666666667",
        "companyID": "2235"
    },
    {
        "Name": "Aumkar Jahagirdar",
        "Roll No.": "200227",
        "Company Name": "Indian Political Action Committee",
        "Profile": "Campaign Manager",
        "Branch": "BT-ME",
        "ctc": "1537000.0",
        "companyID": "2444"
    },
    {
        "Name": "Swayam Gupta",
        "Roll No.": "201035",
        "Company Name": "Fischer Jordan",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Abhay Pratap Jakhar",
        "Roll No.": "200012",
        "Company Name": "Axxela Research & Analytics Private Limited",
        "Profile": "Trainee Analyst",
        "Branch": "BT-MSE",
        "ctc": "1410000.0",
        "companyID": "1821"
    },
    {
        "Name": "Shubhada Mane",
        "Roll No.": "200558",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Product and Development",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "2548"
    },
    {
        "Name": "Umesh Kumar",
        "Roll No.": "201062",
        "Company Name": "Juniper Networks",
        "Profile": "ML Engineer",
        "Branch": "BT-EE",
        "ctc": "2860000.0",
        "companyID": "2368"
    },
    {
        "Name": "Sania Imteyaz",
        "Roll No.": "200861",
        "Company Name": "Accenture Solutions Pvt. Ltd",
        "Profile": "MC Delivery Associate",
        "Branch": "BT-CHE",
        "ctc": "1592000.0",
        "companyID": "1855"
    },
    {
        "Name": "Bharat Sethia",
        "Roll No.": "200267",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-MSE",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Himanshu Sankla",
        "Roll No.": "200445",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-ME",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Manas Manoj Sovani",
        "Roll No.": "22104057",
        "Company Name": "TVS Motor",
        "Profile": "PwD - Design Engineer EEE (D & I HIRING)",
        "Branch": "MT-EE",
        "ctc": "1200000.0",
        "companyID": "2357"
    },
    {
        "Name": "Sairam Nayak Kunsoth",
        "Roll No.": "200841",
        "Company Name": "Merilytics",
        "Profile": "Senior Technical Associate",
        "Branch": "BS-MTH",
        "ctc": "1075000.0",
        "companyID": "2268"
    },
    {
        "Name": "Yash Saxena",
        "Roll No.": "201149",
        "Company Name": "NPCI",
        "Profile": "IT Analyst",
        "Branch": "BT-MSE",
        "ctc": "2006000.0",
        "companyID": "2186"
    },
    {
        "Name": "Saksham Arora",
        "Roll No.": "200843",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BT-CHE",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Prajjwal Rastogi",
        "Roll No.": "200694",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-MSE",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Ritik Raj",
        "Roll No.": "200803",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-ME",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Kavya Jalan",
        "Roll No.": "200503",
        "Company Name": "Pine Labs Pvt. Ltd",
        "Profile": "SDE",
        "Branch": "BT-CSE",
        "ctc": "2250000.0",
        "companyID": "2521"
    },
    {
        "Name": "Anupam Singh",
        "Roll No.": "200168",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BT-BSBE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Parth Govil",
        "Roll No.": "200670",
        "Company Name": "Merilytics",
        "Profile": "Senior Business Analyst",
        "Branch": "BT-CE",
        "ctc": "1150000.0",
        "companyID": "2267"
    },
    {
        "Name": "Abhishek Bansod",
        "Roll No.": "200022",
        "Company Name": "NPCI",
        "Profile": "IT Analyst",
        "Branch": "BT-CSE",
        "ctc": "2006000.0",
        "companyID": "2186"
    },
    {
        "Name": "Gokul Venugopal",
        "Roll No.": "200389",
        "Company Name": "VVF India Ltd",
        "Profile": " Engineer Management Trainee (EMT) - ME",
        "Branch": "BT-ME",
        "ctc": "1600000.0",
        "companyID": "1957"
    },
    {
        "Name": "Siddi Akshay",
        "Roll No.": "200985",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Akash Birthal",
        "Roll No.": "200073",
        "Company Name": "Jindal Shadeed Iron & Steel",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-ME",
        "ctc": "1440000.0",
        "companyID": "2367"
    },
    {
        "Name": "Nivin Vinod",
        "Roll No.": "200652",
        "Company Name": "Citi Bank",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ajeet Kushwaha",
        "Roll No.": "200068",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-CE",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Divya Gupta",
        "Roll No.": "200345",
        "Company Name": "Smarttrak AI",
        "Profile": "Deep Learning Engineer",
        "Branch": "BS-PHY",
        "ctc": "1200000.0",
        "companyID": "2213"
    },
    {
        "Name": "Sabal Jain",
        "Roll No.": "200828",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shreyansh Pachauri",
        "Roll No.": "200954",
        "Company Name": "Indxx",
        "Profile": "Management Trainee",
        "Branch": "BT-CHE",
        "ctc": "1600000.0",
        "companyID": "2228"
    },
    {
        "Name": "Jay Verma",
        "Roll No.": "19807401",
        "Company Name": "Axtria",
        "Profile": "Analyst",
        "Branch": "DualA-CE",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Ayush Singh",
        "Roll No.": "200254",
        "Company Name": "Samsung R&D, Delhi",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "2450000.0",
        "companyID": "2129"
    },
    {
        "Name": "Devansh Singh",
        "Roll No.": "200319",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-CE",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Pulkit Tiwari",
        "Roll No.": "200739",
        "Company Name": "Adobe",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Bodhare Rachit Rajendra",
        "Roll No.": "200283",
        "Company Name": "Cubastion Consulting",
        "Profile": "Graduate Trainee Engineer",
        "Branch": "BT-MSE",
        "ctc": "600000.0",
        "companyID": "1752"
    },
    {
        "Name": "Vaidik Sharma",
        "Roll No.": "201079",
        "Company Name": "JK Tech",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "1500000.0",
        "companyID": "2051"
    },
    {
        "Name": "Subhajit Panday",
        "Roll No.": "22111058",
        "Company Name": "Amway India",
        "Profile": "Technology Trainee - Data Scientist",
        "Branch": "MT-CSE",
        "ctc": "1500000.0",
        "companyID": "2303"
    },
    {
        "Name": "Deepanshi Maheshwari",
        "Roll No.": "200311",
        "Company Name": "Battery Smart",
        "Profile": "Strategy Associate",
        "Branch": "BT-MSE",
        "ctc": "2200000.0",
        "companyID": "2349"
    },
    {
        "Name": "Raaghav Arya",
        "Roll No.": "200745",
        "Company Name": "Texas Instruments",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Prakhar Pratap Mall",
        "Roll No.": "200698",
        "Company Name": "Bajaj Electricals",
        "Profile": "Graduate Engineer Trainee",
        "Branch": "BT-ME",
        "ctc": "1500000.0",
        "companyID": "2517"
    },
    {
        "Name": "Rishi Kachhwaha",
        "Roll No.": "200793",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-MSE",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Suryansh Yadav",
        "Roll No.": "201024",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "BT-ME",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Abhinav Vishwakarma",
        "Roll No.": "200020",
        "Company Name": "NPCI",
        "Profile": "IT Analyst",
        "Branch": "BT-CE",
        "ctc": "2006000.0",
        "companyID": "2186"
    },
    {
        "Name": "Aditya Anand",
        "Roll No.": "200043",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Product and Development",
        "Branch": "BT-ME",
        "ctc": "1500000.0",
        "companyID": "2548"
    },
    {
        "Name": "Kembasaram Nitin",
        "Roll No.": "200505",
        "Company Name": "CapGrid Solutions Pvt. Ltd",
        "Profile": "Software",
        "Branch": "BT-CSE",
        "ctc": "2000000.0",
        "companyID": "2250"
    },
    {
        "Name": "Sanskar Sharma",
        "Roll No.": "200874",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Associate",
        "Branch": "BT-AE",
        "ctc": "1577000.0",
        "companyID": "2240"
    },
    {
        "Name": "Nandini Goel",
        "Roll No.": "200620",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-BSBE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Bvreddy22",
        "Roll No.": "22103020",
        "Company Name": "Aereo",
        "Profile": "Geospatial Data Analyst & Developer",
        "Branch": "MT-CE",
        "ctc": "1266666.6666666667",
        "companyID": "2235"
    },
    {
        "Name": "Aastha Sitpal",
        "Roll No.": "200006",
        "Company Name": "Piramal Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Harshit Kumar Tiwari",
        "Roll No.": "200432",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-CSE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Prakhar Maheshwari",
        "Roll No.": "200697",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Associate",
        "Branch": "BS-ECO",
        "ctc": "1577000.0",
        "companyID": "2240"
    },
    {
        "Name": "Sahil Singh",
        "Roll No.": "200838",
        "Company Name": "Indiejewel Fashions Private Limited (GIVA)",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Subodh Kumar",
        "Roll No.": "201007",
        "Company Name": "Media.net(Directi) ",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "R Darshan",
        "Roll No.": "22101047",
        "Company Name": "Godrej & Boyce",
        "Profile": "Aerospace Engineer",
        "Branch": "MT-AE",
        "ctc": "1200000.0",
        "companyID": "2353"
    },
    {
        "Name": "Sarah Kapoor",
        "Roll No.": "200880",
        "Company Name": "Hindustan Unilever Limited ",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Yash Barjatya",
        "Roll No.": "201138",
        "Company Name": "Zomato",
        "Profile": "Software Development Engineer 1",
        "Branch": "BT-EE",
        "ctc": "2500000.0",
        "companyID": "2115"
    },
    {
        "Name": "Akshit Verma",
        "Roll No.": "200091",
        "Company Name": "Zomato",
        "Profile": "Software Development Engineer 1",
        "Branch": "BT-EE",
        "ctc": "2500000.0",
        "companyID": "2115"
    },
    {
        "Name": "Rohan Singh",
        "Roll No.": "200812",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BT-BSBE",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Akshat Mishra",
        "Roll No.": "200086",
        "Company Name": "Dr. Reddy\u2019s Laboratories",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Roushan Prakash",
        "Roll No.": "190721",
        "Company Name": "Wells Fargo",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sheetal Gupta",
        "Roll No.": "200927",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Abhishek Kumar",
        "Roll No.": "21104401",
        "Company Name": "Delta Electronics",
        "Profile": "Hardware Engineer",
        "Branch": "MSR-EE",
        "ctc": "1200000.0",
        "companyID": "2337"
    },
    {
        "Name": "Krishan Kumar",
        "Roll No.": "200521",
        "Company Name": "Meesho",
        "Profile": "Software Development Engineer I",
        "Branch": "BT-CSE",
        "ctc": "3400000.0",
        "companyID": "1806"
    },
    {
        "Name": "Akhand Pratap Singh",
        "Roll No.": "200075",
        "Company Name": "Nation with Namo",
        "Profile": "Associate",
        "Branch": "BT-CE",
        "ctc": "1900000.0",
        "companyID": "1854"
    },
    {
        "Name": "Sanskriti Sharma",
        "Roll No.": "200876",
        "Company Name": "Flipkart",
        "Profile": "Assistant Manager Business Development ",
        "Branch": "BT-AE",
        "ctc": "1650386.0",
        "companyID": "2301"
    },
    {
        "Name": "Sripathi A D",
        "Roll No.": "22101068",
        "Company Name": "EXL",
        "Profile": "Consultant 1 SBA - Analytics",
        "Branch": "MT-AE",
        "ctc": "900000.0",
        "companyID": "2283"
    },
    {
        "Name": "Aditya Subramanian",
        "Roll No.": "200056",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-AE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Aryan Vora",
        "Roll No.": "200204",
        "Company Name": "Alvarez & Marsal",
        "Profile": "Associate",
        "Branch": "BT-CSE",
        "ctc": "1830000.0",
        "companyID": "2108"
    },
    {
        "Name": "Kushal Sosale",
        "Roll No.": "200540",
        "Company Name": "ITC Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shivam Singhal",
        "Roll No.": "200939",
        "Company Name": "Uber",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Anmol Pabla",
        "Roll No.": "190154",
        "Company Name": "Cohesity",
        "Profile": "Software Developer - Member of Technical Staff",
        "Branch": "DoubleMajor-CSE",
        "ctc": "4308000.0",
        "companyID": "2293"
    },
    {
        "Name": "Kushagra Sharma",
        "Roll No.": "200539",
        "Company Name": "Databricks",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "4090000.0",
        "companyID": "1941"
    },
    {
        "Name": "Chaithanya V",
        "Roll No.": "22119006",
        "Company Name": "Microsoft India",
        "Profile": "Ux Designer",
        "Branch": "MDes-DES",
        "ctc": "2178200.0",
        "companyID": "2306"
    },
    {
        "Name": "Jaya Gupta",
        "Roll No.": "200471",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Anushka Panda",
        "Roll No.": "200174",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Pulkit Dhamija",
        "Roll No.": "200738",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BS-ECO",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Gampala Deepti",
        "Roll No.": "200365",
        "Company Name": "Delta Electronics",
        "Profile": "Hardware Engineer",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "2337"
    },
    {
        "Name": "Nikhil Gupta",
        "Roll No.": "200634",
        "Company Name": "Atlassian",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Saubhagya Bawari",
        "Roll No.": "200899",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-AE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Pradumna Awasthi",
        "Roll No.": "200693",
        "Company Name": "App Orchid Inc",
        "Profile": "Data Sciecne / AI / ML",
        "Branch": "BT-BSBE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Divyansh Gupta",
        "Roll No.": "200351",
        "Company Name": "Axxela Research & Analytics Private Limited",
        "Profile": "Trainee Analyst",
        "Branch": "BS-ECO",
        "ctc": "1410000.0",
        "companyID": "1821"
    },
    {
        "Name": "Ashish Gautam",
        "Roll No.": "200209",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-CE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Viplav Patel",
        "Roll No.": "190976",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Kuldeep Singh Chouhan",
        "Roll No.": "200530",
        "Company Name": "NK Securities Research ",
        "Profile": "Business And Operations Analyst",
        "Branch": "BT-CSE",
        "ctc": "3000000.0",
        "companyID": "2287"
    },
    {
        "Name": "Vivek Agrawal",
        "Roll No.": "201134",
        "Company Name": "CapGrid Solutions Pvt. Ltd",
        "Profile": "Software",
        "Branch": "BT-CHE",
        "ctc": "2000000.0",
        "companyID": "2250"
    },
    {
        "Name": "Harish Mehta",
        "Roll No.": "200404",
        "Company Name": "Merilytics",
        "Profile": "Senior Technical Associate",
        "Branch": "BT-EE",
        "ctc": "1075000.0",
        "companyID": "2268"
    },
    {
        "Name": "Advait Vashi",
        "Roll No.": "200058",
        "Company Name": "Finmechanics",
        "Profile": "Associate Consultant",
        "Branch": "BT-ME",
        "ctc": "1980000.0",
        "companyID": "2033"
    },
    {
        "Name": "Udvas Basak",
        "Roll No.": "201056",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Senior Associate (in-Training)",
        "Branch": "BT-AE",
        "ctc": "1637000.0",
        "companyID": "2241"
    },
    {
        "Name": "Apurb Agarwal",
        "Roll No.": "200179",
        "Company Name": "AlphaGrep Securities Private Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Challa Sai Yohitha",
        "Roll No.": "200289",
        "Company Name": "Accenture Japan",
        "Profile": "Digital Consultant",
        "Branch": "BT-EE",
        "ctc": "1014000.0",
        "companyID": "1911"
    },
    {
        "Name": "Mobashsharah Ali",
        "Roll No.": "200585",
        "Company Name": "CapGrid Solutions Pvt. Ltd",
        "Profile": "Software",
        "Branch": "BT-CHE",
        "ctc": "2000000.0",
        "companyID": "2250"
    },
    {
        "Name": "Gaurav Singh",
        "Roll No.": "200380",
        "Company Name": "Ford Business Solutions",
        "Profile": "Global Data Insight & Analytics ( GDIA )",
        "Branch": "BT-MSE",
        "ctc": "1450000.0",
        "companyID": "2172"
    },
    {
        "Name": "P R Anand Maneesh",
        "Roll No.": "200658",
        "Company Name": "Jindal Shadeed Iron & Steel",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-ME",
        "ctc": "1440000.0",
        "companyID": "2367"
    },
    {
        "Name": "Vedant Bang",
        "Roll No.": "201100",
        "Company Name": "JSW",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sachin Kumar",
        "Roll No.": "200832",
        "Company Name": "Fullerton India Credit Co. Ltd.",
        "Profile": "Digital Collection",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Anshul Mehta",
        "Roll No.": "200154",
        "Company Name": "Dr. Reddy\u2019s Laboratories",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sahil Bansal",
        "Roll No.": "200836",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Yash Dahiya",
        "Roll No.": "201140",
        "Company Name": "Yubi",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Chinmay Agarwal",
        "Roll No.": "200297",
        "Company Name": "Wells Fargo",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Harsh Kumar Pandey",
        "Roll No.": "200414",
        "Company Name": "GAIN Credit",
        "Profile": "Analytics Scientist",
        "Branch": "BT-EE",
        "ctc": "1600000.0",
        "companyID": "2018"
    },
    {
        "Name": "Amit Kumar",
        "Roll No.": "200109",
        "Company Name": "Indxx",
        "Profile": "Management Trainee",
        "Branch": "BT-CHE",
        "ctc": "1600000.0",
        "companyID": "2228"
    },
    {
        "Name": "C.H Alan Harshan",
        "Roll No.": "200286",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Electronics HW Design Engineer Trainee",
        "Branch": "BT-EE",
        "ctc": "2502000.0",
        "companyID": "2209"
    },
    {
        "Name": "Karunanidhi Rajpoot",
        "Roll No.": "19821421",
        "Company Name": "Meesho",
        "Profile": "Associate Product Manager I",
        "Branch": "MDes-DES",
        "ctc": "2600000.0",
        "companyID": "2152"
    },
    {
        "Name": "Aryan Raj",
        "Roll No.": "200202",
        "Company Name": "VVF India Ltd",
        "Profile": " Engineer Management Trainee (EMT) - ME",
        "Branch": "BT-ME",
        "ctc": "1600000.0",
        "companyID": "1957"
    },
    {
        "Name": "Ujjawal Goyal",
        "Roll No.": "201058",
        "Company Name": "GreyOrange",
        "Profile": "SDE",
        "Branch": "BT-CSE",
        "ctc": "2500000.0",
        "companyID": "2332"
    },
    {
        "Name": "Faheem Nizar",
        "Roll No.": "200360",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Product and Development",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "2548"
    },
    {
        "Name": "Kumar Abhishek",
        "Roll No.": "200531",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Product and Development",
        "Branch": "BT-ME",
        "ctc": "1500000.0",
        "companyID": "2548"
    },
    {
        "Name": "Melvin Thomas",
        "Roll No.": "200582",
        "Company Name": "IDFC FIRST Bank ",
        "Profile": "Associate Data Analyst ",
        "Branch": "BT-ME",
        "ctc": "2300000.0",
        "companyID": "2331"
    },
    {
        "Name": "Ankur Maurya",
        "Roll No.": "200142",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "BT-CE",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Gutta Raghavendra Chowdary",
        "Roll No.": "200396",
        "Company Name": "Samsung R&D, Delhi",
        "Profile": "Engineer",
        "Branch": "BT-CSE",
        "ctc": "2450000.0",
        "companyID": "2129"
    },
    {
        "Name": "Yatharth Singh",
        "Roll No.": "201159",
        "Company Name": "SLB",
        "Profile": "PIO-PPO",
        "Branch": "BS-ECO",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Gauri G Menon",
        "Roll No.": "200382",
        "Company Name": "Publicis Sapient",
        "Profile": "Data Science",
        "Branch": "BT-BSBE",
        "ctc": "1675555.0",
        "companyID": "2302"
    },
    {
        "Name": "Mrinal Kumar",
        "Roll No.": "200600",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Adit Thampi",
        "Roll No.": "200039",
        "Company Name": "Lohum Cleantech Pvt Ltd",
        "Profile": "Graduate Trainee",
        "Branch": "BT-MSE",
        "ctc": "1250000.0",
        "companyID": "2343"
    },
    {
        "Name": "Harjap Singh",
        "Roll No.": "200405",
        "Company Name": "Auronova Consulting",
        "Profile": "Risk Management Consulting",
        "Branch": "BT-CHE",
        "ctc": "1400000.0",
        "companyID": "2392"
    },
    {
        "Name": "Hitesh Anand",
        "Roll No.": "200449",
        "Company Name": "WorldQuant",
        "Profile": "Quantitative Researcher",
        "Branch": "BT-CSE",
        "ctc": "8700000.0",
        "companyID": "2378"
    },
    {
        "Name": "Priya Gole",
        "Roll No.": "200727",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Kshitij Shrivastava",
        "Roll No.": "200527",
        "Company Name": "Cisco",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Satyansha Dev",
        "Roll No.": "200897",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Product and Development",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "2548"
    },
    {
        "Name": "Varsha Rani",
        "Roll No.": "201087",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate EV-Powertrain Engineer Trainee",
        "Branch": "BT-EE",
        "ctc": "2352000.0",
        "companyID": "2177"
    },
    {
        "Name": "Mehul Goyal",
        "Roll No.": "200581",
        "Company Name": "Adobe",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Utkarsh Kandi",
        "Roll No.": "201068",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Risk Associate",
        "Branch": "BT-ME",
        "ctc": "1753830.0",
        "companyID": "1838"
    },
    {
        "Name": "Jaskirat Singh",
        "Roll No.": "19817397",
        "Company Name": "Standard Chartered",
        "Profile": "PIO-PPO",
        "Branch": "DualA-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Devika Sahu",
        "Roll No.": "200324",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Software Engineer Trainee",
        "Branch": "BT-MSE",
        "ctc": "2352000.0",
        "companyID": "2176"
    },
    {
        "Name": "Parth Ahuja",
        "Roll No.": "22114030",
        "Company Name": "Axtria",
        "Profile": "PIO-PPO",
        "Branch": "MT-MS",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Maurya Jadav",
        "Roll No.": "200567",
        "Company Name": "Blitz \u00a9 Bigshort Tails Pvt. Ltd.",
        "Profile": "Software Development Engineer - I",
        "Branch": "BT-CSE",
        "ctc": "1900000.0",
        "companyID": "2352"
    },
    {
        "Name": "Jadhav Pallavi Panditrao",
        "Roll No.": "200461",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Tulika Shukla",
        "Roll No.": "201052",
        "Company Name": "ITC Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Avadhi Jindal",
        "Roll No.": "19816204",
        "Company Name": "Merilytics",
        "Profile": "Senior Business Analyst",
        "Branch": "DualB-ECO",
        "ctc": "1150000.0",
        "companyID": "2267"
    },
    {
        "Name": "Harsh Jain",
        "Roll No.": "22119009",
        "Company Name": "Blue Yonder India Private Limited",
        "Profile": "Associate UX Engineer",
        "Branch": "MDes-DES",
        "ctc": "1260000.0",
        "companyID": "2371"
    },
    {
        "Name": "Sejal Sahu",
        "Roll No.": "200911",
        "Company Name": "Ford Business Solutions",
        "Profile": "Global Data Insight & Analytics ( GDIA )",
        "Branch": "BS-MTH",
        "ctc": "1450000.0",
        "companyID": "2172"
    },
    {
        "Name": "Dhwanit Balwani",
        "Roll No.": "200333",
        "Company Name": "CapitalOne",
        "Profile": "Business Analyst",
        "Branch": "BT-CHE",
        "ctc": "3450000.0",
        "companyID": "2028"
    },
    {
        "Name": "Aryan Sharma",
        "Roll No.": "200203",
        "Company Name": "NK Securities Research ",
        "Profile": "Quantitative Researcher",
        "Branch": "BT-CSE",
        "ctc": "8100000.0",
        "companyID": "2286"
    },
    {
        "Name": "Akshay K Muraleedharan",
        "Roll No.": "200088",
        "Company Name": "NVIDIA ",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Samarpreet Singh",
        "Roll No.": "200848",
        "Company Name": "Databricks",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "4090000.0",
        "companyID": "1941"
    },
    {
        "Name": "Tanmay Chhapola",
        "Roll No.": "201039",
        "Company Name": "Dolat Capital",
        "Profile": "Quantitative Strategist",
        "Branch": "BT-EE",
        "ctc": "2700000.0",
        "companyID": "2178"
    },
    {
        "Name": "Rudransh Gupta",
        "Roll No.": "200823",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-CE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Ananya Priyadarshi",
        "Roll No.": "200120",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Mechatronics Engineering Trainee",
        "Branch": "BT-ME",
        "ctc": "2502000.0",
        "companyID": "2175"
    },
    {
        "Name": "Antariksh Choudhary",
        "Roll No.": "200159",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BS-ECO",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Ayush Raj",
        "Roll No.": "200253",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Associate",
        "Branch": "BT-CHE",
        "ctc": "1577000.0",
        "companyID": "2240"
    },
    {
        "Name": "Sanika Gumaste",
        "Roll No.": "200865",
        "Company Name": "MasterCard",
        "Profile": "Associate Specialist, Product Development",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "2202"
    },
    {
        "Name": "Pranjal Jain",
        "Roll No.": "200701",
        "Company Name": "TransOrg Solutions & Services Pvt Ltd",
        "Profile": "Analyst",
        "Branch": "BS-ES",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Debdeep Paul Chaudhuri",
        "Roll No.": "21111413",
        "Company Name": "United Airlines",
        "Profile": "Associate Data Scientist",
        "Branch": "MSR-CSE",
        "ctc": "1100000.0",
        "companyID": "2398"
    },
    {
        "Name": "Debdeep Paul Chaudhuri",
        "Roll No.": "21111413",
        "Company Name": "United Airlines",
        "Profile": "Associate Data Scientist",
        "Branch": "MSR-CSE",
        "ctc": "1100000.0",
        "companyID": "2398"
    },
    {
        "Name": "Rajan Kumar",
        "Roll No.": "22106012",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-MSE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Huzaifa Ahmed Zaidi",
        "Roll No.": "22103025",
        "Company Name": "CapGrid Solutions Pvt. Ltd",
        "Profile": "Data Scientist",
        "Branch": "MT-CE",
        "ctc": "2000000.0",
        "companyID": "2251"
    },
    {
        "Name": "Manish Tongaonkar",
        "Roll No.": "21101408",
        "Company Name": "ARTPARK",
        "Profile": "Engineer- Structure Design",
        "Branch": "MSR-AE",
        "ctc": "1100000.0",
        "companyID": "2194"
    },
    {
        "Name": "Robin Singh",
        "Roll No.": "22102044",
        "Company Name": "OLA",
        "Profile": "Chemical Engineering",
        "Branch": "MT-CHE",
        "ctc": "2250000.0",
        "companyID": "1923"
    },
    {
        "Name": "Yojan Sharma",
        "Roll No.": "22104129",
        "Company Name": "IdeaForge Technology Pvt. Ltd",
        "Profile": "Engineer I ",
        "Branch": "MT-EE",
        "ctc": "1700000.0",
        "companyID": "2470"
    },
    {
        "Name": "Niti Agarwal",
        "Roll No.": "22103037",
        "Company Name": "ASC Infratech Pvt Ltd",
        "Profile": "Trainee Engineer",
        "Branch": "MT-CE",
        "ctc": "737575.0",
        "companyID": "1927"
    },
    {
        "Name": "Karthik Kumar G R",
        "Roll No.": "22104044",
        "Company Name": "Texas Instruments",
        "Profile": "Digital Engineer",
        "Branch": "MT-EE",
        "ctc": "3927190.0",
        "companyID": "2153"
    },
    {
        "Name": "Shivanand Namdeo Sankpal",
        "Roll No.": "22101063",
        "Company Name": "Airbus Group India",
        "Profile": "Associate Engineer: System Installation",
        "Branch": "MT-AE",
        "ctc": "1100000.0",
        "companyID": "1946"
    },
    {
        "Name": "Ruben N",
        "Roll No.": "22101055",
        "Company Name": "ARTPARK",
        "Profile": "Engineer- Structure Design",
        "Branch": "MT-AE",
        "ctc": "1100000.0",
        "companyID": "2194"
    },
    {
        "Name": "Sambhav Agarwal",
        "Roll No.": "200852",
        "Company Name": "Centre for Development of Telematics (C-DOT)",
        "Profile": "RESEARCH ENGINEER",
        "Branch": "BT-EE",
        "ctc": "1850000.0",
        "companyID": "2053"
    },
    {
        "Name": "Richa Prakash Sachan",
        "Roll No.": "200782",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-CE",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Ananya Mehrotra",
        "Roll No.": "200119",
        "Company Name": "CapitalOne",
        "Profile": "Software Engineer",
        "Branch": "BT-EE",
        "ctc": "2850000.0",
        "companyID": "2029"
    },
    {
        "Name": "Anmol",
        "Roll No.": "200143",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BS-MTH",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Jai Anmol Sharma",
        "Roll No.": "200462",
        "Company Name": "Niva Bupa Health Insurance",
        "Profile": "Crest Executive Trainee \u2013 IT",
        "Branch": "BT-ME",
        "ctc": "1860000.0",
        "companyID": "2380"
    },
    {
        "Name": "Navya Ratnan",
        "Roll No.": "200627",
        "Company Name": "Adobe",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shruti Gupta",
        "Roll No.": "200958",
        "Company Name": "FPL TEchnologies Pvt. Ltd",
        "Profile": "Data Scientist",
        "Branch": "BT-CHE",
        "ctc": "2000000.0",
        "companyID": "2263"
    },
    {
        "Name": "Amit Jain",
        "Roll No.": "200108",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-CHE",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Aditya Kulkarni",
        "Roll No.": "200047",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Senior Associate (in-Training)",
        "Branch": "BT-MSE",
        "ctc": "1637000.0",
        "companyID": "2241"
    },
    {
        "Name": "Penta Ramtej",
        "Roll No.": "200683",
        "Company Name": "SEDEMAC Mechatronics Pvt. Ltd.",
        "Profile": "Engineer, Test Automation",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "1937"
    },
    {
        "Name": "Harbeer Gurjar",
        "Roll No.": "200400",
        "Company Name": "Stripe",
        "Profile": "Software Engineer",
        "Branch": "BT-CHE",
        "ctc": "6000000.0",
        "companyID": "1839"
    },
    {
        "Name": "Suket Raj",
        "Roll No.": "201013",
        "Company Name": "Databricks",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "4090000.0",
        "companyID": "1941"
    },
    {
        "Name": "Akhil Jain",
        "Roll No.": "200077",
        "Company Name": "D.E. Shaw",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Akash Biswas",
        "Roll No.": "200074",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Naman Jain",
        "Roll No.": "200618",
        "Company Name": "Ingram Micro",
        "Profile": "IT - SOFTWARE DEVELOPMENT ENGINEER \n",
        "Branch": "BT-MSE",
        "ctc": "1800000.0",
        "companyID": "2100"
    },
    {
        "Name": "Nishant Roshan",
        "Roll No.": "200643",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Siddesh Bharat Hazare",
        "Roll No.": "200976",
        "Company Name": "EightFold AI",
        "Profile": "PIO-PPO",
        "Branch": "BT-AE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Mayank Saini",
        "Roll No.": "200573",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Product and Development",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "2548"
    },
    {
        "Name": "Priya Singh",
        "Roll No.": "200729",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BS-ECO",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Arnav Gupta",
        "Roll No.": "200186",
        "Company Name": "Graviton Research Capital",
        "Profile": "Quantitative Researcher",
        "Branch": "BT-CSE",
        "ctc": "8400000.0",
        "companyID": "2015"
    },
    {
        "Name": "Shubhangi Gupta",
        "Roll No.": "200973",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Analyst",
        "Branch": "BS-MTH",
        "ctc": "3013880.0",
        "companyID": "2272"
    },
    {
        "Name": "Uttam Kumar",
        "Roll No.": "201071",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Aarchie",
        "Roll No.": "200004",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Vedant Sanjay Gitte",
        "Roll No.": "201104",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "BT-EE",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Pradhyumna Lavania",
        "Roll No.": "200692",
        "Company Name": "Dr. Reddy\u2019s Laboratories",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Aditya Singh Kaurav",
        "Roll No.": "200055",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-CHE",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Ayush Pandey",
        "Roll No.": "200248",
        "Company Name": "Amadeus Software Labs",
        "Profile": "Software Development Engineer 2",
        "Branch": "BT-CE",
        "ctc": "1859224.0",
        "companyID": "2364"
    },
    {
        "Name": "Krishan Pandey",
        "Roll No.": "22119011",
        "Company Name": "IBM",
        "Profile": "Visual Design",
        "Branch": "MDes-DES",
        "ctc": "1500000.0",
        "companyID": "2347"
    },
    {
        "Name": "Bipplav Kumar Tiwari",
        "Roll No.": "200281",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ablokit Joshi",
        "Roll No.": "200030",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-MSE",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Aishwarya Srivastava",
        "Roll No.": "200064",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-EE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Aditya Kushwaha",
        "Roll No.": "200051",
        "Company Name": "Auronova Consulting",
        "Profile": "Risk Management Consulting",
        "Branch": "BT-CHE",
        "ctc": "1400000.0",
        "companyID": "2392"
    },
    {
        "Name": "Aditya Kushwaha",
        "Roll No.": "200051",
        "Company Name": "Auronova Consulting",
        "Profile": "Risk Management Consulting",
        "Branch": "BT-CHE",
        "ctc": "1400000.0",
        "companyID": "2392"
    },
    {
        "Name": "Janhvi Rochwani",
        "Roll No.": "200467",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Jigyashu Garg",
        "Roll No.": "200478",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Harsh Chaudhary",
        "Roll No.": "200410",
        "Company Name": "Cisco",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kaustubh Agrawal",
        "Roll No.": "200501",
        "Company Name": "Battery Smart",
        "Profile": "Associate Product Manager",
        "Branch": "BT-CHE",
        "ctc": "2200000.0",
        "companyID": "2350"
    },
    {
        "Name": "Yash Gupta",
        "Roll No.": "190997",
        "Company Name": "Quantbox Research",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sanyam Singla",
        "Roll No.": "200879",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "GTE'24",
        "Branch": "BT-ME",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Pratik Amolkumar Shaha",
        "Roll No.": "22114022",
        "Company Name": "Citi Bank, Bangalore",
        "Profile": "Business Analyst",
        "Branch": "MT-MS",
        "ctc": "1750000.0",
        "companyID": "2180"
    },
    {
        "Name": "Satender Kumar Yadav",
        "Roll No.": "200889",
        "Company Name": "Blitz \u00a9 Bigshort Tails Pvt. Ltd.",
        "Profile": "Software Development Engineer - I",
        "Branch": "BT-EE",
        "ctc": "1900000.0",
        "companyID": "2352"
    },
    {
        "Name": "Aryaman Badkul",
        "Roll No.": "200195",
        "Company Name": "Meesho",
        "Profile": "Associate Product Manager I",
        "Branch": "BT-AE",
        "ctc": "2600000.0",
        "companyID": "2152"
    },
    {
        "Name": "Vaibhav Kuril",
        "Roll No.": "201077",
        "Company Name": "Petronet LNG Limited",
        "Profile": "Petronet LNG Limited (PLL) formed on April 2, 1998, as Joint Venture Company (JVC) having 50% shareholding of leading 4 Oil & Gas PSUs by GOI order dated July 4, 1997\nAn Independent Board managed JVC created for development of facilities for the import, storage and regasification of Liquefied Natural Gas.\nWith equity participation from four Oil & Gas Maharatanas viz. Oil & Natural Gas Corporation (ONGC), Indian Oil Corporation Limited (IOCL), GAIL (India) Limited (GAIL) and Bharat Petroleum Corporation Limited (BPCL).",
        "Branch": "BT-EE",
        "ctc": "1893000.0",
        "companyID": "1975"
    },
    {
        "Name": "Abhay Sisodia",
        "Roll No.": "200014",
        "Company Name": "AuxoAI",
        "Profile": "AI Engineer",
        "Branch": "BT-CHE",
        "ctc": "2576936.0",
        "companyID": "2111"
    },
    {
        "Name": "Priyaa20",
        "Roll No.": "200726",
        "Company Name": "Jindal Shadeed Iron & Steel",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-EE",
        "ctc": "1440000.0",
        "companyID": "2367"
    },
    {
        "Name": "Sidhartha Watsa",
        "Roll No.": "190843",
        "Company Name": "Samsung Research, Bangalore ",
        "Profile": "Advance Developer - Research Profile",
        "Branch": "DoubleMajor-EE",
        "ctc": "4000000.0",
        "companyID": "2275"
    },
    {
        "Name": "Anurag Bohra",
        "Roll No.": "200170",
        "Company Name": "Standard Chartered",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sanmati Dhananjay Pande",
        "Roll No.": "200870",
        "Company Name": "ITC Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shreyaans Jain",
        "Roll No.": "200952",
        "Company Name": "MasterCard",
        "Profile": "Data Engineer",
        "Branch": "BT-AE",
        "ctc": "1200000.0",
        "companyID": "2190"
    },
    {
        "Name": "Dhruv Khandelwal",
        "Roll No.": "200331",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Software Development Engineer 1 (SDE 1)",
        "Branch": "BT-ME",
        "ctc": "2053830.0",
        "companyID": "1837"
    },
    {
        "Name": "Upen Mishra",
        "Roll No.": "201063",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-CE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Aditya Pratap Singh",
        "Roll No.": "200053",
        "Company Name": "NVIDIA ",
        "Profile": "Verification Engineer",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "2230"
    },
    {
        "Name": "Afraz Jamal",
        "Roll No.": "200059",
        "Company Name": "Battery Smart",
        "Profile": "Strategy Associate",
        "Branch": "BT-BSBE",
        "ctc": "2200000.0",
        "companyID": "2349"
    },
    {
        "Name": "Km Ripakshi Singh",
        "Roll No.": "22104049",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "GTE'24",
        "Branch": "MT-EE",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Shreyansh Agarwal",
        "Roll No.": "200953",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sabyasachi Mohanty",
        "Roll No.": "21129270",
        "Company Name": "GIST",
        "Profile": "Developer Associate",
        "Branch": "MSR-SEE",
        "ctc": "1200000.0",
        "companyID": "1979"
    },
    {
        "Name": "Aditi Chouhan",
        "Roll No.": "200040",
        "Company Name": "Accenture Japan",
        "Profile": "Digital Consultant",
        "Branch": "BT-CHE",
        "ctc": "1014000.0",
        "companyID": "1911"
    },
    {
        "Name": "T Shiva Shruthi",
        "Roll No.": "19807890",
        "Company Name": "TATA ADVANCED SYSTEMS LIMITED",
        "Profile": "Post Graduate Engineer Trainee",
        "Branch": "DualA-ME",
        "ctc": "800000.0",
        "companyID": "2142"
    },
    {
        "Name": "Priyanshu Kumar",
        "Roll No.": "190651",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Pratyush Gupta",
        "Roll No.": "200717",
        "Company Name": "OLA",
        "Profile": "Research engineer 1",
        "Branch": "BT-CSE",
        "ctc": "3500000.0",
        "companyID": "1922"
    },
    {
        "Name": "Ronit Agarwal",
        "Roll No.": "200819",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-CHE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Nishi Mehta",
        "Roll No.": "200645",
        "Company Name": "Adobe",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "L Gokulnath",
        "Roll No.": "200542",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Vaibhav Goyal",
        "Roll No.": "201075",
        "Company Name": "Indiejewel Fashions Private Limited (GIVA)",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Abhishek Sangwan",
        "Roll No.": "200021",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-CE",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Shubhankari Rai",
        "Roll No.": "200974",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-CE",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Abhinav Kumar",
        "Roll No.": "200016",
        "Company Name": "SRF LIMITED",
        "Profile": "Design Trainee",
        "Branch": "BT-CHE",
        "ctc": "1000000.0",
        "companyID": "1738"
    },
    {
        "Name": "Jhaansi Reddy",
        "Roll No.": "200477",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "C Navya Nirmala",
        "Roll No.": "22102403",
        "Company Name": "PharmaACE",
        "Profile": "Consultant",
        "Branch": "MSR-CHE",
        "ctc": "1215000.0",
        "companyID": "2320"
    },
    {
        "Name": "Thota Vishnudatta",
        "Roll No.": "201051",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Shubham Sinha",
        "Roll No.": "21111409",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Data Scientist ",
        "Branch": "MSR-CSE",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Prabhat Meena",
        "Roll No.": "200688",
        "Company Name": "Jindal Shadeed Iron & Steel",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-CE",
        "ctc": "1440000.0",
        "companyID": "2367"
    },
    {
        "Name": "Harsh Garg",
        "Roll No.": "200411",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BT-ME",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Aastik Guru",
        "Roll No.": "200007",
        "Company Name": "GLS Services",
        "Profile": "Operations Engineer ",
        "Branch": "BT-ME",
        "ctc": "3144120.0",
        "companyID": "2059"
    },
    {
        "Name": "Rajarshi Dutta",
        "Roll No.": "200762",
        "Company Name": "Decision Point Pvt Ltd",
        "Profile": "Data Scientist ",
        "Branch": "BT-MSE",
        "ctc": "800000.0",
        "companyID": "2307"
    },
    {
        "Name": "Divyansh Manakchand Kankariya",
        "Roll No.": "200352",
        "Company Name": "Kivi Capital",
        "Profile": "Quant Developer",
        "Branch": "BT-CSE",
        "ctc": "4500000.0",
        "companyID": "2147"
    },
    {
        "Name": "Arpit Kumar",
        "Roll No.": "200189",
        "Company Name": "Xion Multiventures Pvt Ltd",
        "Profile": "Trainee Research Analysis & Operation Support  ",
        "Branch": "BT-CSE",
        "ctc": "1620000.0",
        "companyID": "1938"
    },
    {
        "Name": "Ankur Kumar",
        "Roll No.": "200140",
        "Company Name": "SigIQ AI",
        "Profile": "Backend engineer",
        "Branch": "BT-CSE",
        "ctc": "12800000.0",
        "companyID": "2499"
    },
    {
        "Name": "Mandvi Rajpoot",
        "Roll No.": "200557",
        "Company Name": "Cubastion Consulting",
        "Profile": "Graduate Trainee Engineer",
        "Branch": "BT-CE",
        "ctc": "600000.0",
        "companyID": "1752"
    },
    {
        "Name": "Harish Prasad Allam",
        "Roll No.": "200094",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "BT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Mohit Gupta",
        "Roll No.": "200597",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Gargi Naladkar",
        "Roll No.": "200371",
        "Company Name": "Enphase energy",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Riktesh Singh",
        "Roll No.": "200785",
        "Company Name": "Samsung Research, Bangalore ",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "4000000.0",
        "companyID": "2275"
    },
    {
        "Name": "Dhara Sharma",
        "Roll No.": "200326",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-ME",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Ayush Gupta",
        "Roll No.": "200244",
        "Company Name": "Pine Labs Pvt. Ltd",
        "Profile": "SDE",
        "Branch": "BT-ME",
        "ctc": "2250000.0",
        "companyID": "2521"
    },
    {
        "Name": "Pratyush Dayal",
        "Roll No.": "200715",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-ME",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Yash Raj Mittal",
        "Roll No.": "201148",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-CSE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Shreya Bhattacharya",
        "Roll No.": "200950",
        "Company Name": "Zomato",
        "Profile": "Product Analyst",
        "Branch": "BT-MSE",
        "ctc": "1800000.0",
        "companyID": "2181"
    },
    {
        "Name": "Diksha",
        "Roll No.": "200338",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "BT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Adarsh Kumar",
        "Roll No.": "200033",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Harsh Sachan",
        "Roll No.": "200418",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-CHE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Gaurang Dangayach",
        "Roll No.": "200373",
        "Company Name": "MasterCard",
        "Profile": "Associate Specialist, Product Development",
        "Branch": "BS-MTH",
        "ctc": "1200000.0",
        "companyID": "2202"
    },
    {
        "Name": "Saral Verma",
        "Roll No.": "190767",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-CE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kajal Deep",
        "Roll No.": "200483",
        "Company Name": "Cohesity",
        "Profile": "Software Developer - Member of Technical Staff",
        "Branch": "BT-CSE",
        "ctc": "4308000.0",
        "companyID": "2293"
    },
    {
        "Name": "Khoobayshee Aggarwal",
        "Roll No.": "200511",
        "Company Name": "TVS Motor",
        "Profile": "Data Engineer",
        "Branch": "BT-MSE",
        "ctc": "1200000.0",
        "companyID": "2357"
    },
    {
        "Name": "Poojitha",
        "Roll No.": "201094",
        "Company Name": "SAP Labs",
        "Profile": "Associate Developer -Cloud Native API Platform ",
        "Branch": "BT-CSE",
        "ctc": "4072200.0",
        "companyID": "2435"
    },
    {
        "Name": "Varun Maghnani",
        "Roll No.": "201092",
        "Company Name": "EVERSANA",
        "Profile": "PIO-PPO",
        "Branch": "BS-ECO",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Raghav Modani",
        "Roll No.": "200750",
        "Company Name": "FPL TEchnologies Pvt. Ltd",
        "Profile": "Software Engineer",
        "Branch": "BT-CHE",
        "ctc": "2000000.0",
        "companyID": "2262"
    },
    {
        "Name": "Nikita Singh",
        "Roll No.": "200638",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-ME",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Dheeraj Bana",
        "Roll No.": "19807286",
        "Company Name": "Hilti Technology Solutions India",
        "Profile": "Technical Engineer (GET)",
        "Branch": "DualA-CE",
        "ctc": "1900000.0",
        "companyID": "2098"
    },
    {
        "Name": "Akshat Garg",
        "Roll No.": "200084",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-CSE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Aakarsh Mittal",
        "Roll No.": "200002",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Atharva Dehadraya",
        "Roll No.": "200218",
        "Company Name": "Aereo",
        "Profile": "Autopilot Control System Engineer",
        "Branch": "BT-ME",
        "ctc": "1500000.0",
        "companyID": "2236"
    },
    {
        "Name": "Sushmita",
        "Roll No.": "201027",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "BT-CHE",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Abu Kashan",
        "Roll No.": "200031",
        "Company Name": "Hilabs",
        "Profile": "Data Scientist",
        "Branch": "BS-ECO",
        "ctc": "3293750.0",
        "companyID": "2012"
    },
    {
        "Name": "Muditt Khurana",
        "Roll No.": "200602",
        "Company Name": "WorldQuant",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "8700000.0",
        "companyID": "2378"
    },
    {
        "Name": "Garvit Arora",
        "Roll No.": "200372",
        "Company Name": "SAMSUNG South Korea",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sachin",
        "Roll No.": "200830",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Software Development Engineer 1 (SDE 1)",
        "Branch": "BT-EE",
        "ctc": "2053830.0",
        "companyID": "1837"
    },
    {
        "Name": "Dwij Raj Hari",
        "Roll No.": "200358",
        "Company Name": "Stripe",
        "Profile": "Software Engineer",
        "Branch": "BT-MSE",
        "ctc": "6000000.0",
        "companyID": "1839"
    },
    {
        "Name": "Niharika Khatri",
        "Roll No.": "200632",
        "Company Name": "Uber",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ishit Darania",
        "Roll No.": "190390",
        "Company Name": "Navi",
        "Profile": "Data Scientist",
        "Branch": "DoubleMajor-MTH",
        "ctc": "4100000.0",
        "companyID": "2313"
    },
    {
        "Name": "Nitin Kumar",
        "Roll No.": "200649",
        "Company Name": "TATA 1MG",
        "Profile": "Associate Product Manager",
        "Branch": "BS-PHY",
        "ctc": "1800000.0",
        "companyID": "2122"
    },
    {
        "Name": "Sudhanshu Kumar",
        "Roll No.": "201010",
        "Company Name": "Cubastion Consulting",
        "Profile": "Graduate Trainee Engineer",
        "Branch": "BT-MSE",
        "ctc": "600000.0",
        "companyID": "1752"
    },
    {
        "Name": "Anoop Singh Rathore",
        "Roll No.": "200147",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-CHE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Ashish Ahuja",
        "Roll No.": "190191",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kshitiz Mittal",
        "Roll No.": "200528",
        "Company Name": "Axxela Research & Analytics Private Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "1410000.0",
        "companyID": "1821"
    },
    {
        "Name": "Rishika Gupta",
        "Roll No.": "200796",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-ME",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Satvik Chandra Shukla",
        "Roll No.": "200891",
        "Company Name": "Battery Smart",
        "Profile": "Business Analyst",
        "Branch": "BT-ME",
        "ctc": "2200000.0",
        "companyID": "2348"
    },
    {
        "Name": "Aryan Garg",
        "Roll No.": "200199",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Risk Associate",
        "Branch": "BT-AE",
        "ctc": "1753830.0",
        "companyID": "1838"
    },
    {
        "Name": "Abhiyanshu Kumar",
        "Roll No.": "200029",
        "Company Name": "Axxela Research & Analytics Private Limited",
        "Profile": "Trainee Analyst",
        "Branch": "BT-AE",
        "ctc": "1410000.0",
        "companyID": "1821"
    },
    {
        "Name": "Aditya Jain",
        "Roll No.": "200046",
        "Company Name": "Juniper Networks",
        "Profile": "ML Engineer",
        "Branch": "BT-EE",
        "ctc": "2860000.0",
        "companyID": "2368"
    },
    {
        "Name": "Rathod Preet",
        "Roll No.": "200775",
        "Company Name": "Pine Labs Pvt. Ltd",
        "Profile": "SDE",
        "Branch": "BT-CSE",
        "ctc": "2250000.0",
        "companyID": "2521"
    },
    {
        "Name": "Avi Kumar",
        "Roll No.": "200229",
        "Company Name": "GLEAN SEARCH TECHNOLOGIES INDIA Pvt. Ltd.",
        "Profile": "Software Engineer ( US )",
        "Branch": "BT-CSE",
        "ctc": "1920000.0",
        "companyID": "2087"
    },
    {
        "Name": "Vishal Kushwaha",
        "Roll No.": "201128",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sanidhya Singh",
        "Roll No.": "200864",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Abhishek Mishra",
        "Roll No.": "200025",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Software Engineer",
        "Branch": "BT-EE",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Nikund Jain",
        "Roll No.": "200639",
        "Company Name": "Blitz \u00a9 Bigshort Tails Pvt. Ltd.",
        "Profile": "Business Analyst",
        "Branch": "BT-CHE",
        "ctc": "1465000.0",
        "companyID": "2351"
    },
    {
        "Name": "Ujwal Kumar",
        "Roll No.": "201061",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Associate - Product & Technology",
        "Branch": "BT-CHE",
        "ctc": "1500000.0",
        "companyID": "2442"
    },
    {
        "Name": "Shashwat Gupta",
        "Roll No.": "200923",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Associate - Product & Technology",
        "Branch": "BT-CSE",
        "ctc": "1500000.0",
        "companyID": "2442"
    },
    {
        "Name": "Mohammad Umam",
        "Roll No.": "200595",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Mukul Jakhar",
        "Roll No.": "200606",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BS-ECO",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Srijan Singh",
        "Roll No.": "201000",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BT-CE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Samarth Tripathi",
        "Roll No.": "200851",
        "Company Name": "SEDEMAC Mechatronics Pvt. Ltd.",
        "Profile": "Engineer, R&D",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "1935"
    },
    {
        "Name": "Napa Jayaprakash",
        "Roll No.": "200622",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-CSE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Nikhil Rathore",
        "Roll No.": "200635",
        "Company Name": "Standard Chartered",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Utkarsh Gupta",
        "Roll No.": "201067",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "BT-CE",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Vibhanshu Patidar",
        "Roll No.": "201106",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Md Saif",
        "Roll No.": "200577",
        "Company Name": "Indxx",
        "Profile": "Management Trainee",
        "Branch": "BT-CHE",
        "ctc": "1600000.0",
        "companyID": "2228"
    },
    {
        "Name": "Vikas Varshney",
        "Roll No.": "201118",
        "Company Name": "Zomato",
        "Profile": "Software Development Engineer 1",
        "Branch": "BT-CE",
        "ctc": "2500000.0",
        "companyID": "2115"
    },
    {
        "Name": "Kunwar Preet Singh",
        "Roll No.": "200536",
        "Company Name": "Graviton Research Capital",
        "Profile": "Software engineer",
        "Branch": "BT-CSE",
        "ctc": "8400000.0",
        "companyID": "2016"
    },
    {
        "Name": "Manas Kumar",
        "Roll No.": "200555",
        "Company Name": "GyanDhan",
        "Profile": "Business Analyst",
        "Branch": "BT-EE",
        "ctc": "2600000.0",
        "companyID": "2483"
    },
    {
        "Name": "Ayush Anand",
        "Roll No.": "200238",
        "Company Name": "Finmechanics",
        "Profile": "Associate Consultant",
        "Branch": "BT-CHE",
        "ctc": "1980000.0",
        "companyID": "2033"
    },
    {
        "Name": "Dakshita Mittal",
        "Roll No.": "200305",
        "Company Name": "Alvarez & Marsal",
        "Profile": "Associate",
        "Branch": "BT-AE",
        "ctc": "1830000.0",
        "companyID": "2108"
    },
    {
        "Name": "Harshit Bansal",
        "Roll No.": "200428",
        "Company Name": "NK Securities Research ",
        "Profile": "Software Developer",
        "Branch": "BT-CSE",
        "ctc": "10800000.0",
        "companyID": "2285"
    },
    {
        "Name": "Mandar Wayal",
        "Roll No.": "200556",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Aruna Angelin D",
        "Roll No.": "22119005",
        "Company Name": "Blue Yonder India Private Limited",
        "Profile": "Associate UX Engineer",
        "Branch": "MDes-DES",
        "ctc": "1260000.0",
        "companyID": "2371"
    },
    {
        "Name": "Priyanka Meena",
        "Roll No.": "200731",
        "Company Name": "SAP Labs",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Prem Bharwani",
        "Roll No.": "200269",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-CE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sanskriti Vardhan",
        "Roll No.": "200877",
        "Company Name": "Vedanta Resources Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "2100000.0",
        "companyID": "2276"
    },
    {
        "Name": "Divya M",
        "Roll No.": "200346",
        "Company Name": "SLB",
        "Profile": "PIO-PPO",
        "Branch": "BT-AE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Saumya Saini",
        "Roll No.": "200901",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-EE",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Payal Singh",
        "Roll No.": "200682",
        "Company Name": "Fullerton India Credit Co. Ltd.",
        "Profile": "Analytics ",
        "Branch": "BT-CE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Ayush Kumar",
        "Roll No.": "200246",
        "Company Name": "Texas Instruments",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Priyal Agrawal",
        "Roll No.": "200730",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Harsh Sharma",
        "Roll No.": "200420",
        "Company Name": "Niva Bupa Health Insurance",
        "Profile": "Crest Executive Trainee \u2013 IT",
        "Branch": "BT-AE",
        "ctc": "1860000.0",
        "companyID": "2380"
    },
    {
        "Name": "Adi Pratap Singh",
        "Roll No.": "200036",
        "Company Name": "Sprinklr",
        "Profile": "Product Engineer",
        "Branch": "BT-CSE",
        "ctc": "3000000.0",
        "companyID": "2022"
    },
    {
        "Name": "Ujjwal Kumar",
        "Roll No.": "201059",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BT-CSE",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Akshat Bajaj",
        "Roll No.": "200083",
        "Company Name": "ICICI Lombard GIC LTD",
        "Profile": "Senior Manager Actuarial Analyst",
        "Branch": "BT-CHE",
        "ctc": "1200000.0",
        "companyID": "2094"
    },
    {
        "Name": "Vaishnavi Singh",
        "Roll No.": "201082",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Associate",
        "Branch": "BT-CE",
        "ctc": "1577000.0",
        "companyID": "2240"
    },
    {
        "Name": "Isha Agrawal",
        "Roll No.": "200452",
        "Company Name": "Pine Labs Pvt. Ltd",
        "Profile": "APM",
        "Branch": "BT-MSE",
        "ctc": "2250000.0",
        "companyID": "2557"
    },
    {
        "Name": "Anjanesh Rakesh",
        "Roll No.": "200133",
        "Company Name": "Qualcomm",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Naman Singla",
        "Roll No.": "200619",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Vivek Agrawal",
        "Roll No.": "201133",
        "Company Name": "NVIDIA ",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shubham Kumar",
        "Roll No.": "200966",
        "Company Name": "Wells Fargo",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Narendra Jugalkishor Prajapat",
        "Roll No.": "200623",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-CE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Munna Kumar",
        "Roll No.": "200608",
        "Company Name": "Centre for Development of Telematics (C-DOT)",
        "Profile": "RESEARCH ENGINEER",
        "Branch": "BT-EE",
        "ctc": "1850000.0",
        "companyID": "2053"
    },
    {
        "Name": "Apeksha Agrawal",
        "Roll No.": "200176",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Data Scientist ",
        "Branch": "BS-ECO",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Anaavi Alok",
        "Roll No.": "200116",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Piyush Beegala",
        "Roll No.": "200685",
        "Company Name": "Graviton Research Capital",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kevin Thomas Benoy",
        "Roll No.": "200510",
        "Company Name": "Texas Instruments",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Suryanshu Kumar Jaiswal",
        "Roll No.": "201025",
        "Company Name": "Hindustan Unilever Limited ",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Aayushi Mishra",
        "Roll No.": "200009",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Rishwan Reddy",
        "Roll No.": "200562",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Harsit Sinha",
        "Roll No.": "200436",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "BT-CHE",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Siddharth Yadav",
        "Roll No.": "200983",
        "Company Name": "Battery Smart",
        "Profile": "Business Analyst",
        "Branch": "BS-ECO",
        "ctc": "2200000.0",
        "companyID": "2348"
    },
    {
        "Name": "Siddharth Yadav",
        "Roll No.": "200983",
        "Company Name": "Battery Smart",
        "Profile": "Business Analyst",
        "Branch": "BS-ECO",
        "ctc": "2200000.0",
        "companyID": "2348"
    },
    {
        "Name": "Aniket",
        "Roll No.": "200124",
        "Company Name": "FPL TEchnologies Pvt. Ltd",
        "Profile": "Data Scientist",
        "Branch": "BT-ME",
        "ctc": "2000000.0",
        "companyID": "2263"
    },
    {
        "Name": "Aniket",
        "Roll No.": "200124",
        "Company Name": "FPL TEchnologies Pvt. Ltd",
        "Profile": "Data Scientist",
        "Branch": "BT-ME",
        "ctc": "2000000.0",
        "companyID": "2263"
    },
    {
        "Name": "Prashant Kumar Mishra",
        "Roll No.": "200708",
        "Company Name": "Zomato",
        "Profile": "Product Analyst",
        "Branch": "BS-ECO",
        "ctc": "1800000.0",
        "companyID": "2181"
    },
    {
        "Name": "Sameer Khan",
        "Roll No.": "200853",
        "Company Name": "ICICI Lombard GIC LTD",
        "Profile": "Senior Manager Data Scientist",
        "Branch": "BT-CE",
        "ctc": "1230000.0",
        "companyID": "2095"
    },
    {
        "Name": "Divyansh Patel",
        "Roll No.": "200353",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-CE",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Solanki Kevalkumar Balvantbhai",
        "Roll No.": "200991",
        "Company Name": "SAP Labs",
        "Profile": "Associate Developer -Cloud Native API Platform ",
        "Branch": "BT-CSE",
        "ctc": "4072200.0",
        "companyID": "2435"
    },
    {
        "Name": "Shreya Nigwal",
        "Roll No.": "200951",
        "Company Name": "Cubastion Consulting",
        "Profile": "Graduate Trainee Engineer",
        "Branch": "BT-CHE",
        "ctc": "600000.0",
        "companyID": "1752"
    },
    {
        "Name": "Sheeshram Choudhary",
        "Roll No.": "200926",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Associate",
        "Branch": "BT-EE",
        "ctc": "1577000.0",
        "companyID": "2240"
    },
    {
        "Name": "Chandan Singh Naruka",
        "Roll No.": "200290",
        "Company Name": "Indxx",
        "Profile": "Management Trainee",
        "Branch": "BT-CE",
        "ctc": "1600000.0",
        "companyID": "2228"
    },
    {
        "Name": "P Madhav",
        "Roll No.": "200657",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Software Engineer Trainee",
        "Branch": "BT-CHE",
        "ctc": "2352000.0",
        "companyID": "2176"
    },
    {
        "Name": "Anshika Singh",
        "Roll No.": "200149",
        "Company Name": "Vedanta Resources Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "2100000.0",
        "companyID": "2276"
    },
    {
        "Name": "Ansh Saxena",
        "Roll No.": "190157",
        "Company Name": "Sprinklr",
        "Profile": "Product Engineer",
        "Branch": "DoubleMajor-MTH",
        "ctc": "3000000.0",
        "companyID": "2022"
    },
    {
        "Name": "Vedasree Tatimanu",
        "Roll No.": "201049",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Tanmay Grover",
        "Roll No.": "201040",
        "Company Name": "GyanDhan",
        "Profile": "Business Analyst",
        "Branch": "BT-EE",
        "ctc": "2600000.0",
        "companyID": "2483"
    },
    {
        "Name": "Riya Banik",
        "Roll No.": "200809",
        "Company Name": "Standard Chartered",
        "Profile": "PIO-PPO",
        "Branch": "BT-CE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Himanshu Kumar",
        "Roll No.": "200443",
        "Company Name": "Smarttrak AI",
        "Profile": "Deep Learning Engineer",
        "Branch": "BS-ES",
        "ctc": "1200000.0",
        "companyID": "2213"
    },
    {
        "Name": "Dhanya",
        "Roll No.": "19807282",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "DualA-CE",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Ashi Vijayvargiya",
        "Roll No.": "200206",
        "Company Name": "Citi Bank",
        "Profile": "PIO-PPO",
        "Branch": "BS-ECO",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Rashmi Waghmare",
        "Roll No.": "200771",
        "Company Name": "Amadeus Software Labs",
        "Profile": "Software Development Engineer 2",
        "Branch": "BS-MTH",
        "ctc": "1859224.0",
        "companyID": "2364"
    },
    {
        "Name": "Akshat Saklecha",
        "Roll No.": "200842",
        "Company Name": "FPL TEchnologies Pvt. Ltd",
        "Profile": "Data Scientist",
        "Branch": "BT-AE",
        "ctc": "2000000.0",
        "companyID": "2263"
    },
    {
        "Name": "Akshat Saklecha",
        "Roll No.": "200842",
        "Company Name": "FPL TEchnologies Pvt. Ltd",
        "Profile": "Data Scientist",
        "Branch": "BT-AE",
        "ctc": "2000000.0",
        "companyID": "2263"
    },
    {
        "Name": "Rose Agarwal",
        "Roll No.": "200821",
        "Company Name": "Arthur D. Little",
        "Profile": "Business Analyst Trainee",
        "Branch": "BT-CHE",
        "ctc": "2050000.0",
        "companyID": "2372"
    },
    {
        "Name": "Aditya Tanwar",
        "Roll No.": "200057",
        "Company Name": "GLEAN SEARCH TECHNOLOGIES INDIA Pvt. Ltd.",
        "Profile": "Software Engineer ( US )",
        "Branch": "BT-CSE",
        "ctc": "1920000.0",
        "companyID": "2087"
    },
    {
        "Name": "Sangh Priya Gautam",
        "Roll No.": "200859",
        "Company Name": "HPCL",
        "Profile": "Officer- Engineering",
        "Branch": "BT-ME",
        "ctc": "1697000.0",
        "companyID": "2077"
    },
    {
        "Name": "Praveen Singh",
        "Roll No.": "200721",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Samarth Arora",
        "Roll No.": "200849",
        "Company Name": "Graviton Research Capital",
        "Profile": "Quantitative Researcher",
        "Branch": "BT-CSE",
        "ctc": "8400000.0",
        "companyID": "2015"
    },
    {
        "Name": "Vidhi Jain",
        "Roll No.": "201109",
        "Company Name": "Dr. Reddy\u2019s Laboratories",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Suhani",
        "Roll No.": "201011",
        "Company Name": "Proctor & Gamble",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ishan Singh",
        "Roll No.": "200457",
        "Company Name": "Indxx",
        "Profile": "Management Trainee",
        "Branch": "BT-CHE",
        "ctc": "1600000.0",
        "companyID": "2228"
    },
    {
        "Name": "Vijay Bharadwaj",
        "Roll No.": "201112",
        "Company Name": "Sprinklr",
        "Profile": "Product Analyst",
        "Branch": "BT-ME",
        "ctc": "1500000.0",
        "companyID": "2023"
    },
    {
        "Name": "R Sriramchandher",
        "Roll No.": "200744",
        "Company Name": "C3iHub (IHub NTIHAC Foundation), IIT Kanpur",
        "Profile": "Software Development Engineer - SOC",
        "Branch": "BT-EE",
        "ctc": "2800000.0",
        "companyID": "2488"
    },
    {
        "Name": "Aryan Jain",
        "Roll No.": "200201",
        "Company Name": "Quantbox Research",
        "Profile": "DevOps Engineer",
        "Branch": "BS-MTH",
        "ctc": "2500000.0",
        "companyID": "2558"
    },
    {
        "Name": "Yas Vir Singh",
        "Roll No.": "201137",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BT-CE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Animesh Tiwari",
        "Roll No.": "200127",
        "Company Name": "Battery Smart",
        "Profile": "Strategy Associate",
        "Branch": "BT-CE",
        "ctc": "2200000.0",
        "companyID": "2349"
    },
    {
        "Name": "Aman Yadav",
        "Roll No.": "190109",
        "Company Name": "Zomato",
        "Profile": "Software Development Engineer 1",
        "Branch": "DoubleMajor-EE",
        "ctc": "2500000.0",
        "companyID": "2115"
    },
    {
        "Name": "Sharath Kumar V",
        "Roll No.": "200916",
        "Company Name": "Atlassian",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Tanushree Jalewa",
        "Roll No.": "201044",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Yash Gupta",
        "Roll No.": "201143",
        "Company Name": "GAIN Credit",
        "Profile": "Analytics Scientist",
        "Branch": "BT-ME",
        "ctc": "1600000.0",
        "companyID": "2018"
    },
    {
        "Name": "Sarthak Kohli",
        "Roll No.": "200886",
        "Company Name": "McKinsey & Company",
        "Profile": "Business Analyst",
        "Branch": "BT-CSE",
        "ctc": "1950000.0",
        "companyID": "2149"
    },
    {
        "Name": "Aditya Jain",
        "Roll No.": "200045",
        "Company Name": "Samsung R&D, Delhi",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "2450000.0",
        "companyID": "2129"
    },
    {
        "Name": "Karan Jeyasankar",
        "Roll No.": "200490",
        "Company Name": "Signalchip Innovations Pvt Ltd ",
        "Profile": "Electronics - Communication Systems - Design and Development",
        "Branch": "BT-EE",
        "ctc": "1400000.0",
        "companyID": "2377"
    },
    {
        "Name": "Gujrathi Prem Milind",
        "Roll No.": "200393",
        "Company Name": "Indus Insights & Analytics Services",
        "Profile": "Associate",
        "Branch": "BT-EE",
        "ctc": "1577000.0",
        "companyID": "2240"
    },
    {
        "Name": "Parth Bhatt",
        "Roll No.": "200669",
        "Company Name": "Media.net(Directi) ",
        "Profile": "Senior Product Analyst",
        "Branch": "BT-CE",
        "ctc": "2116000.0",
        "companyID": "2439"
    },
    {
        "Name": "Shrey Wadhawan",
        "Roll No.": "200948",
        "Company Name": "Atlassian",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Rohit Agrawal",
        "Roll No.": "200814",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Data Engineer",
        "Branch": "BS-ECO",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Astik Yadav",
        "Roll No.": "200217",
        "Company Name": " FN Mathlogic Consulting Services Private Limited",
        "Profile": "Analyst",
        "Branch": "BT-CE",
        "ctc": "1212000.0",
        "companyID": "1697"
    },
    {
        "Name": "Paramveer Singh Choudhary",
        "Roll No.": "200665",
        "Company Name": "Cisco",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Jahnavi Kairamkonda",
        "Roll No.": "200482",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-CSE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Yash Goel",
        "Roll No.": "201142",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Prabuddha Singh",
        "Roll No.": "200691",
        "Company Name": "Menon and Menon Limited",
        "Profile": "Technical Executive",
        "Branch": "BT-AE",
        "ctc": "1400000.0",
        "companyID": "2110"
    },
    {
        "Name": "Kumar Arpit",
        "Roll No.": "200532",
        "Company Name": "Graviton Research Capital",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Avinash Prasad",
        "Roll No.": "200231",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Arnav Pandey",
        "Roll No.": "200188",
        "Company Name": "Cisco",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Subhrajit Mishra",
        "Roll No.": "201006",
        "Company Name": "Samsung Research, Bangalore ",
        "Profile": "Advance Developer - Research Profile",
        "Branch": "BT-EE",
        "ctc": "4000000.0",
        "companyID": "2275"
    },
    {
        "Name": "Aryaman Singhal",
        "Roll No.": "200196",
        "Company Name": "IDFC FIRST Bank ",
        "Profile": "Associate Data Scientist ",
        "Branch": "BS-MTH",
        "ctc": "2760000.0",
        "companyID": "2330"
    },
    {
        "Name": "Prathamesh Thakare",
        "Roll No.": "19807911",
        "Company Name": "Aspect Ratio Private Limited",
        "Profile": "Analyst (Analytics)",
        "Branch": "DualA-AE",
        "ctc": "1700000.0",
        "companyID": "2131"
    },
    {
        "Name": "Anup Singh",
        "Roll No.": "200166",
        "Company Name": "VVF India Ltd",
        "Profile": " Engineer Management Trainee (EMT) - CHE",
        "Branch": "BT-CHE",
        "ctc": "1600000.0",
        "companyID": "1960"
    },
    {
        "Name": "Aman Pal",
        "Roll No.": "200102",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BT-MSE",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Ujwal Jyot Panda",
        "Roll No.": "201060",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Praful Samadhan Mane",
        "Roll No.": "19807611",
        "Company Name": "Axtria",
        "Profile": "Analyst",
        "Branch": "DualA-CHE",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Granth Choudhary",
        "Roll No.": "200392",
        "Company Name": "Samsung R&D, Delhi",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "2450000.0",
        "companyID": "2129"
    },
    {
        "Name": "Ojsi Goel",
        "Roll No.": "200653",
        "Company Name": "Barclays",
        "Profile": "Decision Analyst",
        "Branch": "BT-MSE",
        "ctc": "1590000.0",
        "companyID": "2116"
    },
    {
        "Name": "Anjali Jain",
        "Roll No.": "200132",
        "Company Name": "MasterCard",
        "Profile": "Data Engineer",
        "Branch": "BT-CE",
        "ctc": "1200000.0",
        "companyID": "2190"
    },
    {
        "Name": "Aditya Kumar Tiwari",
        "Roll No.": "200050",
        "Company Name": "Cisco",
        "Profile": "PIO-PPO",
        "Branch": "BT-CE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Vinit Yogesh Toshniwal",
        "Roll No.": "201123",
        "Company Name": "Bain & Company",
        "Profile": "PIO-PPO",
        "Branch": "BS-ECO",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kuragayala Vasanth",
        "Roll No.": "200537",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Nayan Khandelwal",
        "Roll No.": "200629",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Software Engineer Trainee",
        "Branch": "BT-ME",
        "ctc": "2352000.0",
        "companyID": "2176"
    },
    {
        "Name": "Nayan Khandelwal",
        "Roll No.": "200629",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Software Engineer Trainee",
        "Branch": "BT-ME",
        "ctc": "2352000.0",
        "companyID": "2176"
    },
    {
        "Name": "Devansh Kumar Jha",
        "Roll No.": "200318",
        "Company Name": "Graviton Research Capital",
        "Profile": "Software engineer",
        "Branch": "BT-EE",
        "ctc": "8400000.0",
        "companyID": "2016"
    },
    {
        "Name": "Yashika Malhotra",
        "Roll No.": "201152",
        "Company Name": "Publicis Sapient",
        "Profile": "Data Science",
        "Branch": "BT-AE",
        "ctc": "1675555.0",
        "companyID": "2302"
    },
    {
        "Name": "Kunal Bhoye",
        "Roll No.": "200274",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-CHE",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Dheeraj Singla",
        "Roll No.": "19807287",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Mechatronics Engineering Trainee",
        "Branch": "DualA-ME",
        "ctc": "2502000.0",
        "companyID": "2175"
    },
    {
        "Name": "Surya Bhardwaj",
        "Roll No.": "201022",
        "Company Name": "Vedanta Resources Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "2100000.0",
        "companyID": "2276"
    },
    {
        "Name": "Mahaveer Khurkhuriya",
        "Roll No.": "200550",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-BSBE",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Soham Samaddar",
        "Roll No.": "200990",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shubham",
        "Roll No.": "200965",
        "Company Name": "Savart",
        "Profile": "Data Scientist",
        "Branch": "BT-MSE",
        "ctc": "1500000.0",
        "companyID": "2281"
    },
    {
        "Name": "Prasang Gupta",
        "Roll No.": "200706",
        "Company Name": "Media.net(Directi) ",
        "Profile": "Senior Product Analyst",
        "Branch": "BT-MSE",
        "ctc": "2116000.0",
        "companyID": "2439"
    },
    {
        "Name": "Shubhan R",
        "Roll No.": "200971",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-CSE",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Usha",
        "Roll No.": "200294",
        "Company Name": "Jindal Shadeed Iron & Steel",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-CE",
        "ctc": "1440000.0",
        "companyID": "2367"
    },
    {
        "Name": "Aakash Rathi",
        "Roll No.": "190007",
        "Company Name": "Salesforce",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Apoorva Jha",
        "Roll No.": "200177",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-CE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Anubha Tripathi",
        "Roll No.": "200163",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate EV-Powertrain Engineer Trainee",
        "Branch": "BT-EE",
        "ctc": "2352000.0",
        "companyID": "2177"
    },
    {
        "Name": "Korada Sai Dinesh",
        "Roll No.": "200518",
        "Company Name": "Delta Electronics",
        "Profile": "Software Engineer",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "2400"
    },
    {
        "Name": "Kartavya Damor",
        "Roll No.": "200492",
        "Company Name": "Cohesity",
        "Profile": "Software Developer - Member of Technical Staff",
        "Branch": "BT-CSE",
        "ctc": "4308000.0",
        "companyID": "2293"
    },
    {
        "Name": "Parth Maniar",
        "Roll No.": "200671",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Parth Maniar",
        "Roll No.": "200671",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Nishant Tripathi",
        "Roll No.": "200644",
        "Company Name": "Merilytics",
        "Profile": "Senior Business Analyst",
        "Branch": "BT-CE",
        "ctc": "1150000.0",
        "companyID": "2267"
    },
    {
        "Name": "Ashutosh Muduly",
        "Roll No.": "200215",
        "Company Name": "HPCL",
        "Profile": "Officer- Engineering",
        "Branch": "BT-ME",
        "ctc": "1697000.0",
        "companyID": "2077"
    },
    {
        "Name": "Shubham Jangid",
        "Roll No.": "19817831",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "DualA-CHM",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Harshul Midha",
        "Roll No.": "200435",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Parth Chavan",
        "Roll No.": "200673",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BS-MTH",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Yash Manihar",
        "Roll No.": "201145",
        "Company Name": "Blitz \u00a9 Bigshort Tails Pvt. Ltd.",
        "Profile": "Business Analyst",
        "Branch": "BT-CHE",
        "ctc": "1465000.0",
        "companyID": "2351"
    },
    {
        "Name": "Ayush Pratap Singh",
        "Roll No.": "200251",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-CE",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Mohil",
        "Roll No.": "200596",
        "Company Name": "Centre for Development of Advanced Computing",
        "Profile": "Knowledge Associate   ",
        "Branch": "BT-CSE",
        "ctc": "780000.0",
        "companyID": "2354"
    },
    {
        "Name": "Priyanshu",
        "Roll No.": "200732",
        "Company Name": "FPL TEchnologies Pvt. Ltd",
        "Profile": "Software Engineer",
        "Branch": "BT-ME",
        "ctc": "2000000.0",
        "companyID": "2262"
    },
    {
        "Name": "Rishabh Kaushik",
        "Roll No.": "190703",
        "Company Name": "Samsung Research, Bangalore ",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "4000000.0",
        "companyID": "2275"
    },
    {
        "Name": "Sheshank",
        "Roll No.": "200930",
        "Company Name": "Axxela Research & Analytics Private Limited",
        "Profile": "Trainee Analyst",
        "Branch": "BT-CE",
        "ctc": "1410000.0",
        "companyID": "1821"
    },
    {
        "Name": "Gaurav Sharma",
        "Roll No.": "200379",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-CE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Sanjukta Sen",
        "Roll No.": "22119016",
        "Company Name": "Samsung Design, Delhi",
        "Profile": "PIO-PPO",
        "Branch": "MDes-DES",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Utkarsh Srivastava",
        "Roll No.": "201070",
        "Company Name": "ICICI Bank",
        "Profile": "Management Trainee",
        "Branch": "BT-CE",
        "ctc": "1650990.0",
        "companyID": "2375"
    },
    {
        "Name": "Kuldeep Gupta",
        "Roll No.": "200529",
        "Company Name": "Bajaj Electricals",
        "Profile": "Graduate Engineer Trainee",
        "Branch": "BT-ME",
        "ctc": "1500000.0",
        "companyID": "2517"
    },
    {
        "Name": "Harsh Agrawal",
        "Roll No.": "200407",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ayush Choudhary",
        "Roll No.": "200239",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Risk Associate",
        "Branch": "BT-CE",
        "ctc": "1753830.0",
        "companyID": "1838"
    },
    {
        "Name": "Alok Kumar Thakur",
        "Roll No.": "190100",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "DoubleMajor-MTH",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Rishu Kumar",
        "Roll No.": "200797",
        "Company Name": " FN Mathlogic Consulting Services Private Limited",
        "Profile": "Analyst",
        "Branch": "BT-EE",
        "ctc": "1212000.0",
        "companyID": "1697"
    },
    {
        "Name": "Akshat Agarwal",
        "Roll No.": "200081",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Yashvardhan Rathore",
        "Roll No.": "201154",
        "Company Name": "SLB",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Harshit Singhai",
        "Roll No.": "200434",
        "Company Name": "Meesho",
        "Profile": "Associate Product Manager I",
        "Branch": "BT-AE",
        "ctc": "2600000.0",
        "companyID": "2152"
    },
    {
        "Name": "Shambhavi Sabharwal",
        "Roll No.": "200914",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Mechatronics Engineering Trainee",
        "Branch": "BT-ME",
        "ctc": "2502000.0",
        "companyID": "2175"
    },
    {
        "Name": "Manan Kabra",
        "Roll No.": "200552",
        "Company Name": "Meesho",
        "Profile": "Software Development Engineer I",
        "Branch": "BT-EE",
        "ctc": "3400000.0",
        "companyID": "1806"
    },
    {
        "Name": "Veerannapeta Pravalika",
        "Roll No.": "201105",
        "Company Name": "Deloitte",
        "Profile": "Analyst - Consulting",
        "Branch": "BT-ME",
        "ctc": "1200000.0",
        "companyID": "2155"
    },
    {
        "Name": "Antara Mandal",
        "Roll No.": "200158",
        "Company Name": "TransOrg Solutions & Services Pvt Ltd",
        "Profile": "Analyst",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Gopal Aggarwal",
        "Roll No.": "200390",
        "Company Name": "Pine Labs Pvt. Ltd",
        "Profile": "SDE",
        "Branch": "BT-CSE",
        "ctc": "2250000.0",
        "companyID": "2521"
    },
    {
        "Name": "Alok Kumar",
        "Roll No.": "200095",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Product & Growth Analyst",
        "Branch": "BT-MSE",
        "ctc": "1700000.0",
        "companyID": "2088"
    },
    {
        "Name": "Abhay Singh",
        "Roll No.": "200013",
        "Company Name": "Aspect Ratio Private Limited",
        "Profile": "Analyst (Analytics)",
        "Branch": "BT-ME",
        "ctc": "1700000.0",
        "companyID": "2131"
    },
    {
        "Name": "Shivangi Yadav",
        "Roll No.": "200944",
        "Company Name": "Accenture Solutions Pvt. Ltd",
        "Profile": "MC Delivery Associate",
        "Branch": "BT-CE",
        "ctc": "1592000.0",
        "companyID": "1855"
    },
    {
        "Name": "Romit Mohanty",
        "Roll No.": "19807720",
        "Company Name": "Sprinklr",
        "Profile": "Data Scientist",
        "Branch": "DualA-EE",
        "ctc": "1800000.0",
        "companyID": "2024"
    },
    {
        "Name": "Akhil Agrawal",
        "Roll No.": "200076",
        "Company Name": "Databricks",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "4090000.0",
        "companyID": "1941"
    },
    {
        "Name": "Vedant Garg",
        "Roll No.": "201102",
        "Company Name": "Nation with Namo",
        "Profile": "Associate",
        "Branch": "BT-MSE",
        "ctc": "1900000.0",
        "companyID": "1854"
    },
    {
        "Name": "Sandeep Kumar Bijarnia",
        "Roll No.": "200856",
        "Company Name": "EightFold AI",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Atharv Dusane",
        "Roll No.": "200356",
        "Company Name": "Petronet LNG Limited",
        "Profile": "Petronet LNG Limited (PLL) formed on April 2, 1998, as Joint Venture Company (JVC) having 50% shareholding of leading 4 Oil & Gas PSUs by GOI order dated July 4, 1997\nAn Independent Board managed JVC created for development of facilities for the import, storage and regasification of Liquefied Natural Gas.\nWith equity participation from four Oil & Gas Maharatanas viz. Oil & Natural Gas Corporation (ONGC), Indian Oil Corporation Limited (IOCL), GAIL (India) Limited (GAIL) and Bharat Petroleum Corporation Limited (BPCL).",
        "Branch": "BT-ME",
        "ctc": "1893000.0",
        "companyID": "1975"
    },
    {
        "Name": "Abhishek Raghuvanshi",
        "Roll No.": "22111003",
        "Company Name": "JM Financial",
        "Profile": "Full Stack Web Developer",
        "Branch": "MT-CSE",
        "ctc": "2400000.0",
        "companyID": "2493"
    },
    {
        "Name": "Atirek Aryan",
        "Roll No.": "200221",
        "Company Name": "Vedanta Resources Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "2100000.0",
        "companyID": "2276"
    },
    {
        "Name": "Harsh Saroha",
        "Roll No.": "200419",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BS-MTH",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Himanshu Beniwal",
        "Roll No.": "200441",
        "Company Name": "Niva Bupa Health Insurance",
        "Profile": "Crest Executive Trainee \u2013 IT",
        "Branch": "BT-ME",
        "ctc": "1860000.0",
        "companyID": "2380"
    },
    {
        "Name": "Sarthak Goyal",
        "Roll No.": "200884",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BS-ES",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Chinmay Tewari",
        "Roll No.": "22114010",
        "Company Name": "Barclays",
        "Profile": "Graduate Analyst",
        "Branch": "MT-MS",
        "ctc": "1700000.0",
        "companyID": "2158"
    },
    {
        "Name": "Niranjan Kumar Meena",
        "Roll No.": "200641",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-EE",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Ankit Kumar",
        "Roll No.": "200136",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-EE",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Manan Kalavadia",
        "Roll No.": "200553",
        "Company Name": "Texas Instruments",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Vishal Garg",
        "Roll No.": "201127",
        "Company Name": "Merilytics",
        "Profile": "Senior Business Analyst",
        "Branch": "BT-CE",
        "ctc": "1150000.0",
        "companyID": "2267"
    },
    {
        "Name": "Nikhil Karmachandani",
        "Roll No.": "190551",
        "Company Name": "Xion Multiventures Pvt Ltd",
        "Profile": "Trainee Research Analysis & Operation Support  ",
        "Branch": "DoubleMajor-MSE",
        "ctc": "1620000.0",
        "companyID": "1938"
    },
    {
        "Name": "Ayushi Agrawal",
        "Roll No.": "200257",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-CE",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Ritam Jana",
        "Roll No.": "200798",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "BT-AE",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Devansh Agarwal",
        "Roll No.": "200316",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Nandita Nupur",
        "Roll No.": "22119013",
        "Company Name": "Blue Yonder India Private Limited",
        "Profile": "Associate UX Engineer",
        "Branch": "MDes-DES",
        "ctc": "1260000.0",
        "companyID": "2371"
    },
    {
        "Name": "Mohan Jyotirman Misra",
        "Roll No.": "200589",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "DualA-MSE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Oosheen Tanya",
        "Roll No.": "22119014",
        "Company Name": "MakeMyTrip",
        "Profile": "UX Designer- 2",
        "Branch": "MDes-DES",
        "ctc": "1500000.0",
        "companyID": "2402"
    },
    {
        "Name": "Akshit Singh Chauhan",
        "Roll No.": "200090",
        "Company Name": "BeeHyv Software Solutions",
        "Profile": "Developer Trainee",
        "Branch": "BT-CE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Shankar Pal",
        "Roll No.": "22114026",
        "Company Name": "Merilytics",
        "Profile": "Senior Business Analyst",
        "Branch": "MT-MS",
        "ctc": "1150000.0",
        "companyID": "2267"
    },
    {
        "Name": "Barkha Agrawal",
        "Roll No.": "200263",
        "Company Name": "Vedanta Resources Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "2100000.0",
        "companyID": "2276"
    },
    {
        "Name": "Shreya Agarwal",
        "Roll No.": "200949",
        "Company Name": "Flipkart",
        "Profile": "APM- 1",
        "Branch": "BT-EE",
        "ctc": "2657000.0",
        "companyID": "2112"
    },
    {
        "Name": "Aman Rawat",
        "Roll No.": "22119002",
        "Company Name": "Blue Yonder India Private Limited",
        "Profile": "Associate UX Engineer",
        "Branch": "MDes-DES",
        "ctc": "1260000.0",
        "companyID": "2371"
    },
    {
        "Name": "Devang Kumawat",
        "Roll No.": "200315",
        "Company Name": "Auronova Consulting",
        "Profile": "Risk Management Consulting",
        "Branch": "BT-CHE",
        "ctc": "1400000.0",
        "companyID": "2392"
    },
    {
        "Name": "Vandana Basrani",
        "Roll No.": "201083",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-EE",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Aditya Ranjan",
        "Roll No.": "190068",
        "Company Name": "Google India",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Nikhil Verma",
        "Roll No.": "200637",
        "Company Name": "Sprinklr",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Aryash Pateriya",
        "Roll No.": "190189",
        "Company Name": "Sprinklr",
        "Profile": "Product Engineer",
        "Branch": "DoubleMajor-CSE",
        "ctc": "3000000.0",
        "companyID": "2022"
    },
    {
        "Name": "Jaya Meena",
        "Roll No.": "200472",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-CSE",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Jasjot Singh",
        "Roll No.": "200468",
        "Company Name": "Goldman Sachs",
        "Profile": "Software Engineering | Quantitative Engineering",
        "Branch": "BT-CSE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Harsh Agarwal",
        "Roll No.": "200406",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Chhavi Agrawal",
        "Roll No.": "200295",
        "Company Name": "Salesforce",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Akanksha Singh",
        "Roll No.": "200070",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Parikshit Tomer",
        "Roll No.": "200666",
        "Company Name": "GLS Services",
        "Profile": "Operations Engineer ",
        "Branch": "BT-CHE",
        "ctc": "3144120.0",
        "companyID": "2059"
    },
    {
        "Name": "Akshit Verma",
        "Roll No.": "22119001",
        "Company Name": "Microsoft India",
        "Profile": "Ux Designer",
        "Branch": "MDes-DES",
        "ctc": "2178200.0",
        "companyID": "2306"
    },
    {
        "Name": "Muskan Kumari",
        "Roll No.": "200610",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-MSE",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Shivam Pandey",
        "Roll No.": "200938",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-ME",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Motikar Kshipra Prabhakar",
        "Roll No.": "200598",
        "Company Name": "Dr. Reddy\u2019s Laboratories",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kashishpreet Kaur",
        "Roll No.": "200496",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Varun Gurnani",
        "Roll No.": "201091",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-CE",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Samridh",
        "Roll No.": "200855",
        "Company Name": "Uniorbit Technologies Private Ltd",
        "Profile": "Software Development Engineer 1 (SDE 1)",
        "Branch": "BT-EE",
        "ctc": "2053830.0",
        "companyID": "1837"
    },
    {
        "Name": "Gauri",
        "Roll No.": "200381",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-CE",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Jatin Chauhan",
        "Roll No.": "200469",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-EE",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Riya Saini",
        "Roll No.": "200810",
        "Company Name": "ICICI Lombard GIC LTD",
        "Profile": "Senior Manager Actuarial Analyst",
        "Branch": "BT-CHE",
        "ctc": "1200000.0",
        "companyID": "2094"
    },
    {
        "Name": "Abhishek Pardhi",
        "Roll No.": "200026",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CSE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Aadarsh Shaw",
        "Roll No.": "200001",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-ME",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Akshunya Vijayvargiya",
        "Roll No.": "200092",
        "Company Name": "Databricks",
        "Profile": "Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "4090000.0",
        "companyID": "1941"
    },
    {
        "Name": "Yudhveer",
        "Roll No.": "201166",
        "Company Name": "Navi",
        "Profile": "Software Development Engineer",
        "Branch": "BT-EE",
        "ctc": "4100000.0",
        "companyID": "2312"
    },
    {
        "Name": "Rohit Kumar Gupta",
        "Roll No.": "200816",
        "Company Name": "Google India",
        "Profile": "Software Engineer, University Graduate",
        "Branch": "BT-CE",
        "ctc": "1200000.0",
        "companyID": "2167"
    },
    {
        "Name": "Divy Soni",
        "Roll No.": "200344",
        "Company Name": "Flipkart",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "S Pradeep",
        "Roll No.": "200826",
        "Company Name": "NVIDIA ",
        "Profile": "System Software Engineer",
        "Branch": "BT-CSE",
        "ctc": "3290063.0",
        "companyID": "2217"
    },
    {
        "Name": "Tushar Agarwal",
        "Roll No.": "22102060",
        "Company Name": "Quest Global Engineering Services Pvt. Ltd",
        "Profile": "Engineer ",
        "Branch": "MT-CHE",
        "ctc": "900000.0",
        "companyID": "1830"
    },
    {
        "Name": "Nidhi",
        "Roll No.": "19807546",
        "Company Name": "Thornton Tomasetti",
        "Profile": "Engineer",
        "Branch": "DualA-CE",
        "ctc": "750000.0",
        "companyID": "2300"
    },
    {
        "Name": "Suraj Kumawat",
        "Roll No.": "201021",
        "Company Name": "PricewaterhouseCoopers (US-Adv)",
        "Profile": "Product and Development",
        "Branch": "BT-EE",
        "ctc": "1500000.0",
        "companyID": "2548"
    },
    {
        "Name": "Ketan Shakya",
        "Roll No.": "22104047",
        "Company Name": "Intel",
        "Profile": "Software/ Hardware Engineer",
        "Branch": "MT-EE",
        "ctc": "1977327.0",
        "companyID": "2039"
    },
    {
        "Name": "Pallabi Roy",
        "Roll No.": "22106008",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-MSE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Subrata Das",
        "Roll No.": "22106019",
        "Company Name": "HFCL",
        "Profile": "Post Graduate engineer Trainee",
        "Branch": "MT-MSE",
        "ctc": "1200000.0",
        "companyID": "2471"
    },
    {
        "Name": "Abhay Kumar Dwivedi",
        "Roll No.": "22111001",
        "Company Name": "Pine Labs Pvt. Ltd",
        "Profile": "SDE",
        "Branch": "MT-CSE",
        "ctc": "2250000.0",
        "companyID": "2521"
    },
    {
        "Name": "Ankit Goyal",
        "Roll No.": "22103012",
        "Company Name": "ASC Infratech Pvt Ltd",
        "Profile": "Trainee Engineer",
        "Branch": "MT-CE",
        "ctc": "737575.0",
        "companyID": "1927"
    },
    {
        "Name": "Harsh Trivedi",
        "Roll No.": "200422",
        "Company Name": "Quantbox Research",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Naveen Singh Jugtwan",
        "Roll No.": "22101040",
        "Company Name": "Airbus Group India",
        "Profile": "Associate Flight Controls and Hydraulics Development Engineer",
        "Branch": "MT-AE",
        "ctc": "1100000.0",
        "companyID": "1951"
    },
    {
        "Name": "Abhishek Kumar Singh",
        "Roll No.": "22105002",
        "Company Name": "ISGEC",
        "Profile": "Mechanical",
        "Branch": "MT-ME",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Suchintika Chanda",
        "Roll No.": "22102058",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-CHE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Kapil Singla",
        "Roll No.": "22104405",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MSR-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Ambika Randive",
        "Roll No.": "22102008",
        "Company Name": "KBR",
        "Profile": "Engineer: Chemical \nEngineer: Mechanical",
        "Branch": "MT-CHE",
        "ctc": "950000.0",
        "companyID": "2428"
    },
    {
        "Name": "Priyanka Hembram",
        "Roll No.": "22104075",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "GTE'24",
        "Branch": "MT-EE",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Dhiraj Kumar",
        "Roll No.": "22104403",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "GTE'24",
        "Branch": "MSR-EE",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Ankit Sinha",
        "Roll No.": "22104016",
        "Company Name": "Texas Instruments",
        "Profile": "Analog Engineer",
        "Branch": "MT-EE",
        "ctc": "3927190.0",
        "companyID": "2150"
    },
    {
        "Name": "Vanshika Gupta",
        "Roll No.": "22104123",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "MT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Sai Charan Mekala",
        "Roll No.": "22105069",
        "Company Name": "Western digital",
        "Profile": "Senior Engineer, Packaging Engineering\n",
        "Branch": "MT-ME",
        "ctc": "2117550.0",
        "companyID": "2210"
    },
    {
        "Name": "Anshul Jain",
        "Roll No.": "200153",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-ME",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Sourabh Sen",
        "Roll No.": "22104107",
        "Company Name": "Caterpillar",
        "Profile": "Associate Engineer - Electrical engineering ",
        "Branch": "MT-EE",
        "ctc": "1379280.0",
        "companyID": "2538"
    },
    {
        "Name": "Sai Chandu Kadupu",
        "Roll No.": "22104090",
        "Company Name": "Texas Instruments",
        "Profile": "Analog Engineer",
        "Branch": "MT-EE",
        "ctc": "3927190.0",
        "companyID": "2150"
    },
    {
        "Name": "Ram Kadam",
        "Roll No.": "22105059",
        "Company Name": "Renishaw Metrology ",
        "Profile": "Graduate Software Engineer",
        "Branch": "MT-ME",
        "ctc": "1235000.0",
        "companyID": "1993"
    },
    {
        "Name": "Bishal Sah",
        "Roll No.": "22105019",
        "Company Name": "Jindal Stainless Ltd",
        "Profile": "Post Graduate Engineer Trainee (GET)",
        "Branch": "MT-ME",
        "ctc": "1115000.0",
        "companyID": "2309"
    },
    {
        "Name": "Deborathi Sen",
        "Roll No.": "190256",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sanket Dutta",
        "Roll No.": "21128406",
        "Company Name": "Axtria",
        "Profile": "Analyst",
        "Branch": "MSR-CGS",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Vaibhav Mishra",
        "Roll No.": "22106022",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-MSE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Rahul Kumar Gupta",
        "Roll No.": "21204408",
        "Company Name": "Intel",
        "Profile": "Software/ Hardware Engineer",
        "Branch": "MSR-EE",
        "ctc": "1977327.0",
        "companyID": "2039"
    },
    {
        "Name": "Punyabrat Kalwar",
        "Roll No.": "21211403",
        "Company Name": "Accenture Solutions Pvt Ltd - Data AI",
        "Profile": "Data AI Senior Analyst",
        "Branch": "MSR-CSE",
        "ctc": "1934000.0",
        "companyID": "2138"
    },
    {
        "Name": "Dhananjay Prakash",
        "Roll No.": "22104031",
        "Company Name": "Centre for Development of Telematics (C-DOT)",
        "Profile": "RESEARCH ENGINEER",
        "Branch": "MT-EE",
        "ctc": "1850000.0",
        "companyID": "2053"
    },
    {
        "Name": "Shamayeeta Dass",
        "Roll No.": "200913",
        "Company Name": "Morgan Stanley",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shubham Kumar",
        "Roll No.": "22102054",
        "Company Name": "KBR",
        "Profile": "Engineer: Chemical \nEngineer: Mechanical",
        "Branch": "MT-CHE",
        "ctc": "950000.0",
        "companyID": "2428"
    },
    {
        "Name": "Suchismita Bose",
        "Roll No.": "21116404",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MSR-PSE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Yogesh Nain",
        "Roll No.": "201165",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sonal Agrawal",
        "Roll No.": "200995",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Yerragorla Surendra",
        "Roll No.": "22104128",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Shivam Tripathi",
        "Roll No.": "21111408",
        "Company Name": "Samsung Research, Bangalore ",
        "Profile": "Advance Developer - Research Profile",
        "Branch": "MSR-CSE",
        "ctc": "4000000.0",
        "companyID": "2275"
    },
    {
        "Name": "Deepika Harish",
        "Roll No.": "22104030",
        "Company Name": "Samsung Semiconductor India Research",
        "Profile": " Software- Communication Engineering ",
        "Branch": "MT-EE",
        "ctc": "3110000.0",
        "companyID": "2290"
    },
    {
        "Name": "Akash Kumar",
        "Roll No.": "22104005",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Divyansh Sagar",
        "Roll No.": "22105028",
        "Company Name": "PharmaACE",
        "Profile": "Consultant",
        "Branch": "MT-ME",
        "ctc": "1215000.0",
        "companyID": "2320"
    },
    {
        "Name": "Kushagra Yadav",
        "Roll No.": "22104053",
        "Company Name": "Intel",
        "Profile": "Software/ Hardware Engineer",
        "Branch": "MT-EE",
        "ctc": "1977327.0",
        "companyID": "2039"
    },
    {
        "Name": "Rahul Meena",
        "Roll No.": "22101051",
        "Company Name": "Rosy Blue (India) Pvt. Ltd.",
        "Profile": "Engineering Trainee",
        "Branch": "MT-AE",
        "ctc": "1300000.0",
        "companyID": "2339"
    },
    {
        "Name": "Akshay Nagesh Kamthe",
        "Roll No.": "21204402",
        "Company Name": "Texas Instruments",
        "Profile": "Digital Engineer",
        "Branch": "MSR-EE",
        "ctc": "3927190.0",
        "companyID": "2153"
    },
    {
        "Name": "Allan Robey",
        "Roll No.": "22111007",
        "Company Name": "Taiwan Semiconductor Manufacturing Company",
        "Profile": "Software Engineer (BSID)",
        "Branch": "MT-CSE",
        "ctc": "608123.0",
        "companyID": "2067"
    },
    {
        "Name": "Tejask22",
        "Roll No.": "22104116",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "MT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Devansh Arora",
        "Roll No.": "21201404",
        "Company Name": "Airbus Group India",
        "Profile": "Associate Engineer Aerothermal\n",
        "Branch": "MSR-AE",
        "ctc": "1100000.0",
        "companyID": "1944"
    },
    {
        "Name": "Aditya",
        "Roll No.": "22102007",
        "Company Name": "Quest Global Engineering Services Pvt. Ltd",
        "Profile": "Engineer ",
        "Branch": "MT-CHE",
        "ctc": "900000.0",
        "companyID": "1830"
    },
    {
        "Name": "Siripuram Yamini",
        "Roll No.": "22104105",
        "Company Name": "Texas Instruments",
        "Profile": "Analog Engineer",
        "Branch": "MT-EE",
        "ctc": "3927190.0",
        "companyID": "2150"
    },
    {
        "Name": "Arnab Biswas",
        "Roll No.": "22102013",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-CHE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Diksha Joshi",
        "Roll No.": "22104034",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Nishant Kiran Valvi",
        "Roll No.": "21111407",
        "Company Name": "GIST",
        "Profile": "Developer Associate",
        "Branch": "MSR-CSE",
        "ctc": "1200000.0",
        "companyID": "1979"
    },
    {
        "Name": "Karan Kumar Tiwari",
        "Roll No.": "22101028",
        "Company Name": "Aereo",
        "Profile": "UAV Systems Engineer",
        "Branch": "MT-AE",
        "ctc": "800000.0",
        "companyID": "2235"
    },
    {
        "Name": "Vinayak Ashok Kumbhar",
        "Roll No.": "22104137",
        "Company Name": "Samsung Semiconductor India Research",
        "Profile": "Hardware- Digital (ECE/ VLSI/ Microelectronic)",
        "Branch": "MT-EE",
        "ctc": "3110000.0",
        "companyID": "2289"
    },
    {
        "Name": "Arsh Quayum",
        "Roll No.": "22104130",
        "Company Name": "Texas Instruments",
        "Profile": "Digital Engineer",
        "Branch": "MT-EE",
        "ctc": "3927190.0",
        "companyID": "2153"
    },
    {
        "Name": "Sagar Rothe",
        "Roll No.": "22104088",
        "Company Name": "Texas Instruments",
        "Profile": "Analog Engineer",
        "Branch": "MT-EE",
        "ctc": "3927190.0",
        "companyID": "2150"
    },
    {
        "Name": "Piyush Kumar",
        "Roll No.": "22104069",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Prajakta Kapre",
        "Roll No.": "22103040",
        "Company Name": "Hilti Technology Solutions India",
        "Profile": "Technical Engineer (GET)",
        "Branch": "MT-CE",
        "ctc": "1900000.0",
        "companyID": "2098"
    },
    {
        "Name": "Dharni Sree Kaparaboina",
        "Roll No.": "22106004",
        "Company Name": "Jindal Stainless Ltd",
        "Profile": "Post Graduate Engineer Trainee (GET)",
        "Branch": "MT-MSE",
        "ctc": "1115000.0",
        "companyID": "2309"
    },
    {
        "Name": "Pritesh Sutrakar",
        "Roll No.": "22104074",
        "Company Name": "Onsemi semiconductors",
        "Profile": "ANALOG DESIGN ENGINEER\n",
        "Branch": "MT-EE",
        "ctc": "2100000.0",
        "companyID": "2559"
    },
    {
        "Name": "Shalini Priya",
        "Roll No.": "22103065",
        "Company Name": "UltraTech Cement",
        "Profile": "Management Trainee (Civil - Design & Drawing)",
        "Branch": "MT-CE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Sharat Kirla",
        "Roll No.": "22104096",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Kandana Srichaitanya",
        "Roll No.": "22101027",
        "Company Name": "TATA ADVANCED SYSTEMS LIMITED",
        "Profile": "Post Graduate Engineer Trainee",
        "Branch": "MT-AE",
        "ctc": "800000.0",
        "companyID": "2142"
    },
    {
        "Name": "Akash Kumar",
        "Roll No.": "22104006",
        "Company Name": "TVS Motor",
        "Profile": "Hardware Design Engineer ",
        "Branch": "MT-EE",
        "ctc": "1200000.0",
        "companyID": "2362"
    },
    {
        "Name": "Kudupudi Mohan Kumar",
        "Roll No.": "22105037",
        "Company Name": "SEDEMAC Mechatronics Pvt. Ltd.",
        "Profile": "Engineer, R&D",
        "Branch": "MT-ME",
        "ctc": "1500000.0",
        "companyID": "1935"
    },
    {
        "Name": "Abhishek Gupta",
        "Roll No.": "22102005",
        "Company Name": "OLA",
        "Profile": "Chemical Engineering",
        "Branch": "MT-CHE",
        "ctc": "2250000.0",
        "companyID": "1923"
    },
    {
        "Name": "Manojit Biswas",
        "Roll No.": "22103030",
        "Company Name": "ICICI Lombard GIC LTD",
        "Profile": "Senior Manager - Strategy & Innovation",
        "Branch": "MT-CE",
        "ctc": "2000000.0",
        "companyID": "2456"
    },
    {
        "Name": "Sachin",
        "Roll No.": "22105068",
        "Company Name": "General  Electric",
        "Profile": "Edison Engineering Development Program",
        "Branch": "MT-ME",
        "ctc": "1525000.0",
        "companyID": "2243"
    },
    {
        "Name": "Vikash Kumar Gupta",
        "Roll No.": "22102063",
        "Company Name": "Raspa Pharma Private Limited",
        "Profile": "Senior Research Associate, Bioprocess Engineering",
        "Branch": "MT-CHE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Shubham Sharma",
        "Roll No.": "22104102",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Abhishek Kumar Pathak",
        "Roll No.": "22111002",
        "Company Name": "C3iHub (IHub NTIHAC Foundation), IIT Kanpur",
        "Profile": "Software Development Engineer - SOC",
        "Branch": "MT-CSE",
        "ctc": "2800000.0",
        "companyID": "2488"
    },
    {
        "Name": "Vaihsnav K S",
        "Roll No.": "22104122",
        "Company Name": "Airbus Group India",
        "Profile": "Electrical System Engineer",
        "Branch": "MT-EE",
        "ctc": "1100000.0",
        "companyID": "1948"
    },
    {
        "Name": "Vaidehi Chandrashekhar Nare",
        "Roll No.": "22104121",
        "Company Name": "IdeaForge Technology Pvt. Ltd",
        "Profile": "Engineer I ",
        "Branch": "MT-EE",
        "ctc": "1700000.0",
        "companyID": "2470"
    },
    {
        "Name": "Vikalp Kumar",
        "Roll No.": "22104124",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Shivam Singh",
        "Roll No.": "22103067",
        "Company Name": "GIST",
        "Profile": "Developer Associate",
        "Branch": "MT-CE",
        "ctc": "1200000.0",
        "companyID": "1979"
    },
    {
        "Name": "Vishnu Vardhan Gurrala",
        "Roll No.": "22104139",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "MT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Amrendra",
        "Roll No.": "22104012",
        "Company Name": "Onsemi semiconductors",
        "Profile": "ANALOG DESIGN ENGINEER\n",
        "Branch": "MT-EE",
        "ctc": "2100000.0",
        "companyID": "2559"
    },
    {
        "Name": "Aravindasai Bura",
        "Roll No.": "22104019",
        "Company Name": "Centre for Development of Telematics (C-DOT)",
        "Profile": "RESEARCH ENGINEER",
        "Branch": "MT-EE",
        "ctc": "1850000.0",
        "companyID": "2053"
    },
    {
        "Name": "Prachet Bhattacharya",
        "Roll No.": "22104070",
        "Company Name": "Onsemi semiconductors",
        "Profile": "ANALOG DESIGN ENGINEER\n",
        "Branch": "MT-EE",
        "ctc": "2100000.0",
        "companyID": "2559"
    },
    {
        "Name": "Mayuri Shankarrao Umak",
        "Roll No.": "22102029",
        "Company Name": "PharmaACE",
        "Profile": "Consultant",
        "Branch": "MT-CHE",
        "ctc": "1215000.0",
        "companyID": "2320"
    },
    {
        "Name": "Aamir Alam",
        "Roll No.": "22104001",
        "Company Name": "Samsung Semiconductor India Research",
        "Profile": "Hardware- Digital (ECE/ VLSI/ Microelectronic)",
        "Branch": "MT-EE",
        "ctc": "3110000.0",
        "companyID": "2289"
    },
    {
        "Name": "Sidhi Vishnu Vardhana Chary",
        "Roll No.": "22104103",
        "Company Name": "Delta Electronics",
        "Profile": "Hardware Engineer",
        "Branch": "MT-EE",
        "ctc": "1200000.0",
        "companyID": "2337"
    },
    {
        "Name": "Rupareliya Abhay Ashvinbhai",
        "Roll No.": "22102003",
        "Company Name": "KBR",
        "Profile": "Engineer: Chemical \nEngineer: Mechanical",
        "Branch": "MT-CHE",
        "ctc": "950000.0",
        "companyID": "2428"
    },
    {
        "Name": "Kumar Suryamauli Shah",
        "Roll No.": "22104052",
        "Company Name": "Solar Energy Corporation of India Limited",
        "Profile": "Executive Trainee",
        "Branch": "MT-EE",
        "ctc": "1989891.0",
        "companyID": "2464"
    },
    {
        "Name": "Gudelli Shivakumar",
        "Roll No.": "22129015",
        "Company Name": "Hitachi Energy",
        "Profile": "Project Engineer",
        "Branch": "MT-SEE",
        "ctc": "1000000.0",
        "companyID": "2394"
    },
    {
        "Name": "Jagadeesh Siddula",
        "Roll No.": "22104042",
        "Company Name": "TVS Motor",
        "Profile": "Hardware Design Engineer ",
        "Branch": "MT-EE",
        "ctc": "1200000.0",
        "companyID": "2362"
    },
    {
        "Name": "Ritam Borah",
        "Roll No.": "22105064",
        "Company Name": "PharmaACE",
        "Profile": "Consultant",
        "Branch": "MT-ME",
        "ctc": "1215000.0",
        "companyID": "2320"
    },
    {
        "Name": "Akash S",
        "Roll No.": "22105004",
        "Company Name": "Quest Global Engineering Services Pvt. Ltd",
        "Profile": "Engineer ",
        "Branch": "MT-ME",
        "ctc": "900000.0",
        "companyID": "1830"
    },
    {
        "Name": "Yash Prakash Patil",
        "Roll No.": "21111410",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Software Engineer",
        "Branch": "MSR-CSE",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Sahandeep Das",
        "Roll No.": "22104089",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "MT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Manu S Varghese",
        "Roll No.": "22105040",
        "Company Name": "MRF LIMITED",
        "Profile": "R&D( Executive Technical)",
        "Branch": "MT-ME",
        "ctc": "1028595.0",
        "companyID": "2010"
    },
    {
        "Name": "Debleena Das",
        "Roll No.": "22101407",
        "Company Name": "TATA ADVANCED SYSTEMS LIMITED",
        "Profile": "Post Graduate Engineer Trainee",
        "Branch": "MSR-AE",
        "ctc": "800000.0",
        "companyID": "2142"
    },
    {
        "Name": "Ketavath Tharun Nayak",
        "Roll No.": "22104048",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "MT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Puneet Shrivastava",
        "Roll No.": "22104076",
        "Company Name": "Micron Technology",
        "Profile": "Semiconductor Engineer",
        "Branch": "MT-EE",
        "ctc": "2746471.0",
        "companyID": "2260"
    },
    {
        "Name": "Deepak B Hegde",
        "Roll No.": "21211402",
        "Company Name": "Optym India Private Limited",
        "Profile": "Software Engineer - Algorithm Developer ",
        "Branch": "MSR-CSE",
        "ctc": "2400000.0",
        "companyID": "2383"
    },
    {
        "Name": "Mansi Kumawat",
        "Roll No.": "22104407",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "GTE'24",
        "Branch": "MSR-EE",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Anshika",
        "Roll No.": "22102010",
        "Company Name": "KBR",
        "Profile": "Engineer: Chemical \nEngineer: Mechanical",
        "Branch": "MT-CHE",
        "ctc": "950000.0",
        "companyID": "2428"
    },
    {
        "Name": "Rakesh N",
        "Roll No.": "22104080",
        "Company Name": "Texas Instruments",
        "Profile": "Analog Engineer",
        "Branch": "MT-EE",
        "ctc": "3927190.0",
        "companyID": "2150"
    },
    {
        "Name": "Hari Chandan P",
        "Roll No.": "22106006",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-MSE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Raykar Akshada Mandar",
        "Roll No.": "22106013",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-MSE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Mohammad Aaquib",
        "Roll No.": "22103033",
        "Company Name": "UltraTech Cement",
        "Profile": "Management Trainee (Civil - Design & Drawing)",
        "Branch": "MT-CE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Bhumik Mehra",
        "Roll No.": "200276",
        "Company Name": "Dr. Reddy\u2019s Laboratories",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Abhay Pratap Singh",
        "Roll No.": "22103002",
        "Company Name": "ASC Infratech Pvt Ltd",
        "Profile": "Trainee Engineer",
        "Branch": "MT-CE",
        "ctc": "737575.0",
        "companyID": "1927"
    },
    {
        "Name": "Parthadhwaj Konduparty",
        "Roll No.": "22106009",
        "Company Name": "Tata Steel",
        "Profile": "Management Trainee(R&T)",
        "Branch": "MT-MSE",
        "ctc": "1311258.0",
        "companyID": "2365"
    },
    {
        "Name": "Ruchi Verma",
        "Roll No.": "21104408",
        "Company Name": "Aura Semiconductor Pvt Ltd",
        "Profile": "Design Engineer - Analog",
        "Branch": "MSR-EE",
        "ctc": "2500000.0",
        "companyID": "1841"
    },
    {
        "Name": "Mayank Amrutbhai Shingala",
        "Roll No.": "22101035",
        "Company Name": "NMTronics India Private Limited",
        "Profile": "Robotics Engineer - Software",
        "Branch": "MT-AE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Keshav Birdi",
        "Roll No.": "200506",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-ME",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Arshwin Kumar",
        "Roll No.": "22104021",
        "Company Name": "Samsung Semiconductor India Research",
        "Profile": "Hardware- Digital (ECE/ VLSI/ Microelectronic)",
        "Branch": "MT-EE",
        "ctc": "3110000.0",
        "companyID": "2289"
    },
    {
        "Name": "Aman Agarwal",
        "Roll No.": "200097",
        "Company Name": "Groww",
        "Profile": "Associate Product Manager",
        "Branch": "BT-MSE",
        "ctc": "2800000.0",
        "companyID": "2075"
    },
    {
        "Name": "Sourit Saha",
        "Roll No.": "200998",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Smriti Tripathi",
        "Roll No.": "200988",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "BT-CE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Himanshu Lal",
        "Roll No.": "21111403",
        "Company Name": "Samsung Research, Bangalore ",
        "Profile": "Advance Developer - Research Profile",
        "Branch": "MSR-CSE",
        "ctc": "4000000.0",
        "companyID": "2275"
    },
    {
        "Name": "Jegan Balaji B S",
        "Roll No.": "21111404",
        "Company Name": "Axtria",
        "Profile": "Analyst",
        "Branch": "MSR-CSE",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Shivam Gupta",
        "Roll No.": "22104098",
        "Company Name": "Intel",
        "Profile": "Software/ Hardware Engineer",
        "Branch": "MT-EE",
        "ctc": "1977327.0",
        "companyID": "2039"
    },
    {
        "Name": "Saloni Das",
        "Roll No.": "200845",
        "Company Name": "Barclays",
        "Profile": "Decision Analyst",
        "Branch": "BT-BSBE",
        "ctc": "1590000.0",
        "companyID": "2116"
    },
    {
        "Name": "Arnab Hazra",
        "Roll No.": "22101007",
        "Company Name": "Godrej & Boyce",
        "Profile": "Aerospace Engineer",
        "Branch": "MT-AE",
        "ctc": "1200000.0",
        "companyID": "2353"
    },
    {
        "Name": "Rishabh Singh",
        "Roll No.": "22104083",
        "Company Name": "Signalchip Innovations Pvt Ltd ",
        "Profile": "Electronics - Communication Systems - Design and Development",
        "Branch": "MT-EE",
        "ctc": "1400000.0",
        "companyID": "2377"
    },
    {
        "Name": "Ritwik Das",
        "Roll No.": "22104084",
        "Company Name": "Qualcomm",
        "Profile": "Hardware",
        "Branch": "MT-EE",
        "ctc": "3733000.0",
        "companyID": "2040"
    },
    {
        "Name": "Aditya Mishra",
        "Roll No.": "22103006",
        "Company Name": "Decision Point Pvt Ltd",
        "Profile": "Data Scientist ",
        "Branch": "MT-CE",
        "ctc": "800000.0",
        "companyID": "2307"
    },
    {
        "Name": "Sahil Agrawal",
        "Roll No.": "22103052",
        "Company Name": "Accenture Japan",
        "Profile": "Strategy Consultant",
        "Branch": "MT-CE",
        "ctc": "8683000.0",
        "companyID": "1913"
    },
    {
        "Name": "Saurav Suman",
        "Roll No.": "22103061",
        "Company Name": "ASC Infratech Pvt Ltd",
        "Profile": "Trainee Engineer",
        "Branch": "MT-CE",
        "ctc": "737575.0",
        "companyID": "1927"
    },
    {
        "Name": "Miska Singh",
        "Roll No.": "22103032",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "Data Science Analyst",
        "Branch": "MT-CE",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Darlapudi Venkata Gayatri Prasad",
        "Roll No.": "22101015",
        "Company Name": "MRF LIMITED",
        "Profile": "R&D( Executive Technical)",
        "Branch": "MT-AE",
        "ctc": "1028595.0",
        "companyID": "2010"
    },
    {
        "Name": "Kapil Sharma",
        "Roll No.": "21129408",
        "Company Name": "Jindal Stainless Ltd",
        "Profile": "Post Graduate Engineer Trainee (GET)",
        "Branch": "MSR-SEE",
        "ctc": "1115000.0",
        "companyID": "2309"
    },
    {
        "Name": "Deepak Kushimal",
        "Roll No.": "22105022",
        "Company Name": "ISGEC",
        "Profile": "Mechanical",
        "Branch": "MT-ME",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Kondru Sivakumar",
        "Roll No.": "22105035",
        "Company Name": "Jindal Stainless Ltd",
        "Profile": "Post Graduate Engineer Trainee (GET)",
        "Branch": "MT-ME",
        "ctc": "1115000.0",
        "companyID": "2309"
    },
    {
        "Name": "Fahad Farid",
        "Roll No.": "22105029",
        "Company Name": "ICICI Lombard GIC LTD",
        "Profile": "Senior Manager - Strategy & Innovation",
        "Branch": "MT-ME",
        "ctc": "2000000.0",
        "companyID": "2456"
    },
    {
        "Name": "Abhay Gupta",
        "Roll No.": "22102002",
        "Company Name": "OLA",
        "Profile": "Chemical Engineering",
        "Branch": "MT-CHE",
        "ctc": "2250000.0",
        "companyID": "1923"
    },
    {
        "Name": "Jetti Naga Karthik",
        "Roll No.": "19817404",
        "Company Name": "Ormae",
        "Profile": "Operations Research Scientist I",
        "Branch": "DualA-MTH",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Atanu Shuvam Roy",
        "Roll No.": "22111012",
        "Company Name": "Ford Business Solutions",
        "Profile": "Global Data Insight & Analytics ( GDIA )",
        "Branch": "MT-CSE",
        "ctc": "1450000.0",
        "companyID": "2172"
    },
    {
        "Name": "Yemike Abhilash Chandra",
        "Roll No.": "22111071",
        "Company Name": "Texas Instruments",
        "Profile": "Embedded Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "3927190.0",
        "companyID": "2154"
    },
    {
        "Name": "Chetna Singh",
        "Roll No.": "22111018",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Data Scientist ",
        "Branch": "MT-CSE",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Samarth Joshi",
        "Roll No.": "22111051",
        "Company Name": "SAP Labs",
        "Profile": "Associate Developer -Cloud Native API Platform ",
        "Branch": "MT-CSE",
        "ctc": "4072200.0",
        "companyID": "2435"
    },
    {
        "Name": "Sonam",
        "Roll No.": "22111057",
        "Company Name": "Texas Instruments",
        "Profile": "Embedded Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "3927190.0",
        "companyID": "2154"
    },
    {
        "Name": "Goundla Amith Kumar Goud",
        "Roll No.": "22111023",
        "Company Name": "SAP Labs",
        "Profile": "Associate Developer -Cloud Native API Platform ",
        "Branch": "MT-CSE",
        "ctc": "4072200.0",
        "companyID": "2435"
    },
    {
        "Name": "Ashutosh Shandilya",
        "Roll No.": "22129006",
        "Company Name": "Solar Energy Corporation of India Limited",
        "Profile": "Executive Trainee",
        "Branch": "MT-SEE",
        "ctc": "1989891.0",
        "companyID": "2464"
    },
    {
        "Name": "Vinay Agrawal",
        "Roll No.": "22111068",
        "Company Name": "SAP Labs",
        "Profile": "Associate Developer -Cloud Native API Platform ",
        "Branch": "MT-CSE",
        "ctc": "4072200.0",
        "companyID": "2435"
    },
    {
        "Name": "Mannu Kumar Gaddhyan",
        "Roll No.": "22111041",
        "Company Name": "Amway India",
        "Profile": "Technology Trainee - Data Scientist",
        "Branch": "MT-CSE",
        "ctc": "1500000.0",
        "companyID": "2303"
    },
    {
        "Name": "Shubham Kumar",
        "Roll No.": "200969",
        "Company Name": "Larsen & Toubro Limited",
        "Profile": "Management Trainees",
        "Branch": "BT-CE",
        "ctc": "700000.0",
        "companyID": "2340"
    },
    {
        "Name": "Jayant Prakash",
        "Roll No.": "22129008",
        "Company Name": "Caterpillar",
        "Profile": "Associate Engineer - Battery Modelling and Analysis ",
        "Branch": "MT-SEE",
        "ctc": "1379280.0",
        "companyID": "2536"
    },
    {
        "Name": "Malay Pandey",
        "Roll No.": "22111090",
        "Company Name": "Samsung Research, Bangalore ",
        "Profile": "Advance Developer - Research Profile",
        "Branch": "MT-CSE",
        "ctc": "4000000.0",
        "companyID": "2275"
    },
    {
        "Name": "Srujana Sabbani",
        "Roll No.": "22111083",
        "Company Name": "Hyprbots Systems",
        "Profile": "Software Development Engineer",
        "Branch": "MT-CSE",
        "ctc": "2000000.0",
        "companyID": "2409"
    },
    {
        "Name": "Shree Harish S",
        "Roll No.": "22111081",
        "Company Name": "Centre for Development of Telematics (C-DOT)",
        "Profile": "RESEARCH ENGINEER",
        "Branch": "MT-CSE",
        "ctc": "1850000.0",
        "companyID": "2053"
    },
    {
        "Name": "Keerthana Patchava",
        "Roll No.": "200504",
        "Company Name": "Javis",
        "Profile": "Customer Success Manager I",
        "Branch": "BT-EE",
        "ctc": "2160000.0",
        "companyID": "2299"
    },
    {
        "Name": "Vikram Kumar Kaware",
        "Roll No.": "221465",
        "Company Name": "CapGrid Solutions Pvt. Ltd",
        "Profile": "Data Scientist",
        "Branch": "MSc-Stats",
        "ctc": "2000000.0",
        "companyID": "2251"
    },
    {
        "Name": "Shivang Jaiswal",
        "Roll No.": "200940",
        "Company Name": "Axis Bank",
        "Profile": "Manager",
        "Branch": "BT-MSE",
        "ctc": "1443300.0",
        "companyID": "2170"
    },
    {
        "Name": "Shailza Sharma",
        "Roll No.": "221416",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "PIO-PPO",
        "Branch": "MSc-Stats",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Paulomi Das",
        "Roll No.": "221366",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "PIO-PPO",
        "Branch": "MSc-Stats",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Shubh Tandon",
        "Roll No.": "200964",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Ronak Agarwal",
        "Roll No.": "200818",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "Market Analyst - Trainee",
        "Branch": "BT-EE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Sweta Kumari",
        "Roll No.": "201036",
        "Company Name": "Adobe",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ranjit Prasad",
        "Roll No.": "221387",
        "Company Name": "Citi Bank, Bangalore",
        "Profile": "Business Analyst",
        "Branch": "MSc-Stats",
        "ctc": "1750000.0",
        "companyID": "2180"
    },
    {
        "Name": "Sarvagya Jain",
        "Roll No.": "200888",
        "Company Name": "Axxela Research & Analytics Private Limited",
        "Profile": "Trainee Analyst",
        "Branch": "BT-CE",
        "ctc": "1410000.0",
        "companyID": "1821"
    },
    {
        "Name": "Sweta Kumari",
        "Roll No.": "201037",
        "Company Name": "Uber",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Pratyusha Bala",
        "Roll No.": "221372",
        "Company Name": "Involead",
        "Profile": "Data Scientist",
        "Branch": "MSc-Stats",
        "ctc": "1250000.0",
        "companyID": "1962"
    },
    {
        "Name": "Mohammad Saqib Ansari",
        "Roll No.": "221348",
        "Company Name": "ICICI Lombard GIC LTD",
        "Profile": "Senior Manager Data Scientist",
        "Branch": "MSc-Stats",
        "ctc": "1230000.0",
        "companyID": "2095"
    },
    {
        "Name": "Keshav Gupta",
        "Roll No.": "200507",
        "Company Name": "CapGrid Solutions Pvt. Ltd",
        "Profile": "Software",
        "Branch": "BT-EE",
        "ctc": "2000000.0",
        "companyID": "2250"
    },
    {
        "Name": "Snigdha Taneja",
        "Roll No.": "221428",
        "Company Name": "Standard Chartered",
        "Profile": "PIO-PPO",
        "Branch": "MSc-Stats",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ringan Majumdar",
        "Roll No.": "221390",
        "Company Name": "Involead",
        "Profile": "Data Scientist",
        "Branch": "MSc-Stats",
        "ctc": "1250000.0",
        "companyID": "1962"
    },
    {
        "Name": "Rohit",
        "Roll No.": "200813",
        "Company Name": "C3iHub (IHub NTIHAC Foundation), IIT Kanpur",
        "Profile": "Software Development Engineer - SOC",
        "Branch": "BT-CSE",
        "ctc": "2800000.0",
        "companyID": "2488"
    },
    {
        "Name": "Vrinda Rawal",
        "Roll No.": "221466",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "PIO-PPO",
        "Branch": "MSc-Stats",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Pulkit Sharma",
        "Roll No.": "22111048",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Data Scientist ",
        "Branch": "MT-CSE",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Kaushik Thakkar",
        "Roll No.": "221329",
        "Company Name": "Barclays",
        "Profile": "Graduate Analyst",
        "Branch": "MSc-Stats",
        "ctc": "1700000.0",
        "companyID": "2158"
    },
    {
        "Name": "Gitika Mittal",
        "Roll No.": "200388",
        "Company Name": "Alvarez & Marsal",
        "Profile": "Associate",
        "Branch": "BT-AE",
        "ctc": "1830000.0",
        "companyID": "2108"
    },
    {
        "Name": "Anjali Naithani",
        "Roll No.": "221273",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "PIO-PPO",
        "Branch": "MSc-Stats",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Shruti Bindra",
        "Roll No.": "221422",
        "Company Name": "Axtria",
        "Profile": "PIO-PPO",
        "Branch": "MSc-Stats",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Swarnajit Podder",
        "Roll No.": "221453",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "PIO-PPO",
        "Branch": "MSc-Stats",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Rohit Dutta",
        "Roll No.": "221396",
        "Company Name": "Ford Business Solutions",
        "Profile": "Global Data Insight & Analytics ( GDIA )",
        "Branch": "MSc-Stats",
        "ctc": "1450000.0",
        "companyID": "2172"
    },
    {
        "Name": "Prakhar Gupta",
        "Roll No.": "200696",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Aritra Basak",
        "Roll No.": "221282",
        "Company Name": "Accenture Solutions Pvt Ltd - Data AI",
        "Profile": "Data AI Senior Analyst",
        "Branch": "MSc-Stats",
        "ctc": "1934000.0",
        "companyID": "2138"
    },
    {
        "Name": "Divya Vani Gunturu",
        "Roll No.": "22123007",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "Data Science Analyst",
        "Branch": "MT-ES",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Atul Kumar",
        "Roll No.": "22111013",
        "Company Name": "Fujitsu Research of India Pvt Ltd",
        "Profile": "Software Developer",
        "Branch": "MT-CSE",
        "ctc": "1800000.0",
        "companyID": "1789"
    },
    {
        "Name": "Mohan Krishna",
        "Roll No.": "200590",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "BT-EE",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Dhairya Daga",
        "Roll No.": "221312",
        "Company Name": "Involead",
        "Profile": "Data Scientist",
        "Branch": "MSc-Stats",
        "ctc": "1250000.0",
        "companyID": "1962"
    },
    {
        "Name": "Taneya Soni",
        "Roll No.": "22111062",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Debjani Das",
        "Roll No.": "22118007",
        "Company Name": "PharmaACE",
        "Profile": "Consultant",
        "Branch": "MT-BSBE",
        "ctc": "1215000.0",
        "companyID": "2320"
    },
    {
        "Name": "Abhishek Kumar",
        "Roll No.": "20204402",
        "Company Name": "Texas Instruments",
        "Profile": "Analog Engineer",
        "Branch": "MSR-EE",
        "ctc": "3927190.0",
        "companyID": "2150"
    },
    {
        "Name": "Nihal Thukarama Rao",
        "Roll No.": "22111044",
        "Company Name": "Stripe",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "6000000.0",
        "companyID": "1839"
    },
    {
        "Name": "Anshul Sharma",
        "Roll No.": "22111009",
        "Company Name": "Juniper Networks",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "2760000.0",
        "companyID": "2280"
    },
    {
        "Name": "Yash Uttamchandani",
        "Roll No.": "22111070",
        "Company Name": "Interglobe Aviation Ltd. (IndiGo Airlines)",
        "Profile": "Data Scientist ",
        "Branch": "MT-CSE",
        "ctc": "1600000.0",
        "companyID": "2556"
    },
    {
        "Name": "Ashee Jain",
        "Roll No.": "22111073",
        "Company Name": "SEDEMAC Mechatronics Pvt. Ltd.",
        "Profile": "Engineer, Embedded SW",
        "Branch": "MT-CSE",
        "ctc": "1500000.0",
        "companyID": "1939"
    },
    {
        "Name": "Mounika Dasa",
        "Roll No.": "22128405",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "Data Science Analyst",
        "Branch": "MSR-CGS",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Thishyan Raj T",
        "Roll No.": "20204420",
        "Company Name": "Leapfrog Semiconductor ",
        "Profile": "Software Engineer",
        "Branch": "MSR-EE",
        "ctc": "2750000.0",
        "companyID": "2501"
    },
    {
        "Name": "Raj Kumar",
        "Roll No.": "22111050",
        "Company Name": "Quicksell ",
        "Profile": "Backend Developer",
        "Branch": "MT-CSE",
        "ctc": "1500000.0",
        "companyID": "2140"
    },
    {
        "Name": "Ayush Kothiyal",
        "Roll No.": "22111015",
        "Company Name": "Centific Global Solutions Inc",
        "Profile": "JUNIOR AI ENGINEER",
        "Branch": "MT-CSE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Shrutika Anil Jadhav",
        "Roll No.": "22111082",
        "Company Name": "Flipkart",
        "Profile": "Software development Engineer- 1",
        "Branch": "MT-CSE",
        "ctc": "3257000.0",
        "companyID": "1978"
    },
    {
        "Name": "Roshan Kumar",
        "Roll No.": "20204417",
        "Company Name": "TVS Motor",
        "Profile": "Software Engineer (Cluster and Infotainment)",
        "Branch": "MSR-EE",
        "ctc": "1200000.0",
        "companyID": "2551"
    },
    {
        "Name": "Shubhashish Moitra",
        "Roll No.": "22111055",
        "Company Name": "Samsung Research Institute@ Noida",
        "Profile": "Engineer - R&D",
        "Branch": "MT-CSE",
        "ctc": "2450000.0",
        "companyID": "2126"
    },
    {
        "Name": "Kush Shah",
        "Roll No.": "22111033",
        "Company Name": "Juniper Networks",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "2760000.0",
        "companyID": "2280"
    },
    {
        "Name": "Bharat",
        "Roll No.": "22111074",
        "Company Name": "Ingram Micro",
        "Profile": "IT - SOFTWARE DEVELOPMENT ENGINEER \n",
        "Branch": "MT-CSE",
        "ctc": "1800000.0",
        "companyID": "2100"
    },
    {
        "Name": "Sumit Kumar Chaudhary",
        "Roll No.": "22111060",
        "Company Name": "JK Tech",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "1500000.0",
        "companyID": "2051"
    },
    {
        "Name": "Deepak Mathur",
        "Roll No.": "22111019",
        "Company Name": "Samsung Research Institute@ Noida",
        "Profile": "Engineer - R&D",
        "Branch": "MT-CSE",
        "ctc": "2450000.0",
        "companyID": "2126"
    },
    {
        "Name": "Avnish Tripathi",
        "Roll No.": "22111014",
        "Company Name": "Samsung R&D, Delhi",
        "Profile": "Engineer",
        "Branch": "MT-CSE",
        "ctc": "2450000.0",
        "companyID": "2129"
    },
    {
        "Name": "Vamshikiran Bhaskar Morlawar",
        "Roll No.": "22111066",
        "Company Name": "Pine Labs Pvt. Ltd",
        "Profile": "SDE",
        "Branch": "MT-CSE",
        "ctc": "2250000.0",
        "companyID": "2521"
    },
    {
        "Name": "Arun Kumar Kushwaha",
        "Roll No.": "22129005",
        "Company Name": "Solar Energy Corporation of India Limited",
        "Profile": "Executive Trainee",
        "Branch": "MT-SEE",
        "ctc": "1989891.0",
        "companyID": "2464"
    },
    {
        "Name": "Shubham Rathore",
        "Roll No.": "22111054",
        "Company Name": "Centre for Development of Telematics (C-DOT)",
        "Profile": "RESEARCH ENGINEER",
        "Branch": "MT-CSE",
        "ctc": "1850000.0",
        "companyID": "2053"
    },
    {
        "Name": "Gunj Mehul Hundiwala",
        "Roll No.": "22111024",
        "Company Name": "Accenture Applied Intelligence",
        "Profile": "Data Science Analyst",
        "Branch": "MT-CSE",
        "ctc": "1715000.0",
        "companyID": "2448"
    },
    {
        "Name": "Komal Yadav",
        "Roll No.": "22111031",
        "Company Name": "KAL ATM Software India Pvt. Ltd.",
        "Profile": "Junior Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "2139700.0",
        "companyID": "2199"
    },
    {
        "Name": "Mayank Devnani",
        "Roll No.": "22111042",
        "Company Name": "Palo Alto Networks",
        "Profile": "Associate Engineer ",
        "Branch": "MT-CSE",
        "ctc": "5500000.0",
        "companyID": "2231"
    },
    {
        "Name": "Pushpendra Singh",
        "Roll No.": "22104077",
        "Company Name": "Intel",
        "Profile": "Software/ Hardware Engineer",
        "Branch": "MT-EE",
        "ctc": "1977327.0",
        "companyID": "2039"
    },
    {
        "Name": "Gaurav Kumar Meena",
        "Roll No.": "22103021",
        "Company Name": "Decision Point Pvt Ltd",
        "Profile": "Business Analyst",
        "Branch": "MT-CE",
        "ctc": "800000.0",
        "companyID": "2305"
    },
    {
        "Name": "Bhavya Gupta",
        "Roll No.": "22111017",
        "Company Name": "JK Tech",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "1500000.0",
        "companyID": "2051"
    },
    {
        "Name": "Ushakiran Mannam",
        "Roll No.": "22111063",
        "Company Name": "Juniper Networks",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "2760000.0",
        "companyID": "2280"
    },
    {
        "Name": "Drashtant Singh Rathod",
        "Roll No.": "22111021",
        "Company Name": "Optym India Private Limited",
        "Profile": "Software Engineer - Algorithm Developer ",
        "Branch": "MT-CSE",
        "ctc": "2400000.0",
        "companyID": "2383"
    },
    {
        "Name": "Pradhuman Singh Shaktawat",
        "Roll No.": "22129013",
        "Company Name": "Jindal Stainless Ltd",
        "Profile": "Post Graduate Engineer Trainee (GET)",
        "Branch": "MT-SEE",
        "ctc": "1115000.0",
        "companyID": "2309"
    },
    {
        "Name": "Aditya Kankriya",
        "Roll No.": "22111072",
        "Company Name": "SAP Labs",
        "Profile": "Associate Developer -Cloud Native API Platform ",
        "Branch": "MT-CSE",
        "ctc": "4072200.0",
        "companyID": "2435"
    },
    {
        "Name": "Sudiksha Navik",
        "Roll No.": "22111059",
        "Company Name": "JK Tech",
        "Profile": "Software Engineer",
        "Branch": "MT-CSE",
        "ctc": "1500000.0",
        "companyID": "2051"
    },
    {
        "Name": "Rohit Kale",
        "Roll No.": "19917413",
        "Company Name": "EXL",
        "Profile": "Consultant 1 - Analytics & Digital",
        "Branch": "DualB-ECO",
        "ctc": "1500000.0",
        "companyID": "2282"
    },
    {
        "Name": "Akshay Kumar",
        "Roll No.": "22112001",
        "Company Name": "Sahajanand Medical technology pvt ltd",
        "Profile": "Process Engineer",
        "Branch": "MT-MSP",
        "ctc": "1215025.0",
        "companyID": "2133"
    },
    {
        "Name": "Dharambir Poddar",
        "Roll No.": "19201262",
        "Company Name": "Decision Point Pvt Ltd",
        "Profile": "Business Analyst",
        "Branch": "MT-AE",
        "ctc": "800000.0",
        "companyID": "2305"
    },
    {
        "Name": "Madhav Maheshwari",
        "Roll No.": "22111037",
        "Company Name": "C3iHub (IHub NTIHAC Foundation), IIT Kanpur",
        "Profile": "Software Development Engineer - SOC",
        "Branch": "MT-CSE",
        "ctc": "2800000.0",
        "companyID": "2488"
    },
    {
        "Name": "Ishika Gupta",
        "Roll No.": "221322",
        "Company Name": "Barclays",
        "Profile": "Consumer Credit Risk",
        "Branch": "MSc-Stats",
        "ctc": "1500000.0",
        "companyID": "2218"
    },
    {
        "Name": "Suchandra Sasmal",
        "Roll No.": "221439",
        "Company Name": "Citi Bank, Bangalore",
        "Profile": "Business Analyst",
        "Branch": "MSc-Stats",
        "ctc": "1750000.0",
        "companyID": "2180"
    },
    {
        "Name": "Ajay Vijay Shinde",
        "Roll No.": "22129001",
        "Company Name": "Solar Energy Corporation of India Limited",
        "Profile": "Executive Trainee",
        "Branch": "MT-SEE",
        "ctc": "1989891.0",
        "companyID": "2464"
    },
    {
        "Name": "Ananya Agrawal",
        "Roll No.": "200117",
        "Company Name": "Goldman Sachs",
        "Profile": "Software Engineering | Quantitative Engineering",
        "Branch": "BT-CSE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Nitya Aggarwal",
        "Roll No.": "200651",
        "Company Name": "Hindustan Unilever Limited ",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Mohammad Imad Khan",
        "Roll No.": "190499",
        "Company Name": "Nomura",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Siddharth Mishra",
        "Roll No.": "190841",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "DoubleMajor-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Adit Jain",
        "Roll No.": "200038",
        "Company Name": "Winzo Games",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Aditi Phogat",
        "Roll No.": "200041",
        "Company Name": "MasterCard",
        "Profile": "PIO-PPO",
        "Branch": "BT-AE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ananya Jain",
        "Roll No.": "200118",
        "Company Name": "MasterCard",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Anshuman",
        "Roll No.": "200157",
        "Company Name": "Walmart Global Tech India",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ahmad Amaan",
        "Roll No.": "200062",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Arya Pinaki",
        "Roll No.": "200194",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-BSBE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Avishi Taneja",
        "Roll No.": "200234",
        "Company Name": "J. P Morgan & Chase",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shreenaga Tejas Chikoti",
        "Roll No.": "200296",
        "Company Name": "Qube Research & Technology",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Dibyajyoti Haloi",
        "Roll No.": "200335",
        "Company Name": "Texas Instruments",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Daksh Shrivastava",
        "Roll No.": "200304",
        "Company Name": "Qualcomm",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Bhavya Garg",
        "Roll No.": "200270",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Dishay Mehta",
        "Roll No.": "200341",
        "Company Name": "Quadeye Securities",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Divyanshi Shukla",
        "Roll No.": "200354",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Het Hitendrakumar Patel",
        "Roll No.": "200440",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Himanshu Jindal",
        "Roll No.": "200442",
        "Company Name": "Goldman Sachs",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "3650000.0",
        "companyID": "2327"
    },
    {
        "Name": "Harsh Jain",
        "Roll No.": "200412",
        "Company Name": "SAMSUNG South Korea",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Gaurav Raj",
        "Roll No.": "200378",
        "Company Name": "American Express",
        "Profile": "PIO-PPO",
        "Branch": "BS-ECO",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kumar Saurav",
        "Roll No.": "200533",
        "Company Name": "Wells Fargo",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ishan Bawne",
        "Roll No.": "200456",
        "Company Name": "Finmechanics",
        "Profile": "PIO-PPO",
        "Branch": "BS-PHY",
        "ctc": "1980000.0",
        "companyID": "2033"
    },
    {
        "Name": "Ishaan Shukla",
        "Roll No.": "200455",
        "Company Name": "Oracle India Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kalash",
        "Roll No.": "200484",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BS-PHY",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Kushal Gehlot",
        "Roll No.": "200541",
        "Company Name": "APT Portfolio Private Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Mehta Shrey Kartik",
        "Roll No.": "200580",
        "Company Name": "SAMSUNG South Korea",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Neha Pattanaik",
        "Roll No.": "200630",
        "Company Name": "Piramal Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Parteek",
        "Roll No.": "200668",
        "Company Name": "Optiver",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Pratham Jain",
        "Roll No.": "200712",
        "Company Name": "AlphaGrep Securities Private Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Ritick Gupta",
        "Roll No.": "200801",
        "Company Name": "Atlassian",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Priyanshu Sinha",
        "Roll No.": "200737",
        "Company Name": "Mitsubishi Heavy Industries India Private Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Deepak Sangle",
        "Roll No.": "200860",
        "Company Name": "Visa Inc.",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Rishav Bikarwar",
        "Roll No.": "200792",
        "Company Name": "Graviton Research Capital",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sujal Harkut",
        "Roll No.": "201012",
        "Company Name": "Boston Consulting Group",
        "Profile": "PIO-PPO",
        "Branch": "BT-EE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Shreyansh Sinha",
        "Roll No.": "200955",
        "Company Name": "Morgan Stanley",
        "Profile": "PIO-PPO",
        "Branch": "BS-MTH",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sourabh Mina",
        "Roll No.": "200996",
        "Company Name": "Salesforce",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Somansh Prakash Dubey",
        "Roll No.": "200992",
        "Company Name": "Cisco",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Tejas Ramakrishnan",
        "Roll No.": "201050",
        "Company Name": "SAMSUNG South Korea",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Vartika",
        "Roll No.": "201089",
        "Company Name": "Intuit",
        "Profile": "PIO-PPO",
        "Branch": "BT-CSE",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Varun Gangwar",
        "Roll No.": "201090",
        "Company Name": "Futures First Info Services Pvt Ltd",
        "Profile": "PIO-PPO",
        "Branch": "BT-CHE",
        "ctc": "1288000.0",
        "companyID": "2151"
    },
    {
        "Name": "Hemant Kumar",
        "Roll No.": "22114011",
        "Company Name": "Axtria",
        "Profile": "PIO-PPO",
        "Branch": "MT-MS",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Tushar Goyal",
        "Roll No.": "180826",
        "Company Name": "Microsoft India",
        "Profile": "Software Engineer",
        "Branch": "BT-EE",
        "ctc": "2103200.0",
        "companyID": "2270"
    },
    {
        "Name": "Vatsalya Singh",
        "Roll No.": "190953",
        "Company Name": "Aspect Ratio Private Limited",
        "Profile": "Analyst (Analytics)",
        "Branch": "DoubleMajor-PHY",
        "ctc": "1700000.0",
        "companyID": "2131"
    },
    {
        "Name": "Shorya Kumar",
        "Roll No.": "190818",
        "Company Name": "Databricks",
        "Profile": "Software Engineer",
        "Branch": "DoubleMajor-CSE",
        "ctc": "4090000.0",
        "companyID": "1941"
    },
    {
        "Name": "Sunreet Khanna",
        "Roll No.": "201020",
        "Company Name": "MasterCard",
        "Profile": "Associate Specialist, Product Development",
        "Branch": "BT-EE",
        "ctc": "1200000.0",
        "companyID": "2202"
    },
    {
        "Name": "Shaurya Pratap Singh",
        "Roll No.": "200925",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "GTE'24",
        "Branch": "BT-EE",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Varada Agarwal",
        "Roll No.": "201086",
        "Company Name": " FN Mathlogic Consulting Services Private Limited",
        "Profile": "Analyst",
        "Branch": "BS-MTH",
        "ctc": "1212000.0",
        "companyID": "1697"
    },
    {
        "Name": "Abhishek Shukla",
        "Roll No.": "21205001",
        "Company Name": "PharmaACE",
        "Profile": "Consultant",
        "Branch": "MT-ME",
        "ctc": "1215000.0",
        "companyID": "2320"
    },
    {
        "Name": "Pradeep Singh",
        "Roll No.": "21205006",
        "Company Name": "ISGEC",
        "Profile": "Mechanical",
        "Branch": "MT-ME",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Suhail Sheikh",
        "Roll No.": "21205009",
        "Company Name": "ISGEC",
        "Profile": "Mechanical",
        "Branch": "MT-ME",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Diyan Gupta",
        "Roll No.": "21205004",
        "Company Name": "ISGEC",
        "Profile": "Mechanical",
        "Branch": "MT-ME",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Akash Bhargav",
        "Roll No.": "21205002",
        "Company Name": "KBR",
        "Profile": "Engineer: Chemical \nEngineer: Mechanical",
        "Branch": "MT-ME",
        "ctc": "950000.0",
        "companyID": "2428"
    },
    {
        "Name": "Janhavi Bhoge",
        "Roll No.": "19807396",
        "Company Name": "SLB",
        "Profile": "PIO-PPO",
        "Branch": "DualA-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Tanya Arya",
        "Roll No.": "190899",
        "Company Name": "Amadeus Software Labs",
        "Profile": "Software Development Engineer 2",
        "Branch": "BT-AE",
        "ctc": "1859224.0",
        "companyID": "2364"
    },
    {
        "Name": "Abhimanyu Sethia",
        "Roll No.": "190023",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Analyst",
        "Branch": "DoubleMajor-CSE",
        "ctc": "3013880.0",
        "companyID": "2272"
    },
    {
        "Name": "Arush Kumar Rai",
        "Roll No.": "200192",
        "Company Name": "TATA Projects Limited",
        "Profile": "Executive Trainee",
        "Branch": "BT-CE",
        "ctc": "1575000.0",
        "companyID": "2413"
    },
    {
        "Name": "Ishita Vyavahare",
        "Roll No.": "200459",
        "Company Name": "Flipkart",
        "Profile": "Assistant Manager Business Development ",
        "Branch": "BS-PHY",
        "ctc": "1650386.0",
        "companyID": "2301"
    },
    {
        "Name": "Jayesh S. Baretiya",
        "Roll No.": "200476",
        "Company Name": "ICICI Lombard GIC LTD",
        "Profile": "Senior Manager Actuarial Analyst",
        "Branch": "BS-ECO",
        "ctc": "1200000.0",
        "companyID": "2094"
    },
    {
        "Name": "Karji Anusha Sahu",
        "Roll No.": "200491",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-CE",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Ankit Kumar Meena",
        "Roll No.": "200137",
        "Company Name": "Reliance Industries Limited",
        "Profile": "Graduate Engineer Trainee (GET)",
        "Branch": "BT-ME",
        "ctc": "1050000.0",
        "companyID": "2278"
    },
    {
        "Name": "Rahul Rustagi",
        "Roll No.": "200756",
        "Company Name": "MasterCard",
        "Profile": "Data Engineer",
        "Branch": "BT-AE",
        "ctc": "1200000.0",
        "companyID": "2190"
    },
    {
        "Name": "Pranab Pandey",
        "Roll No.": "190620",
        "Company Name": "Graviton Research Capital",
        "Profile": "Software engineer",
        "Branch": "DoubleMajor-CSE",
        "ctc": "8400000.0",
        "companyID": "2016"
    },
    {
        "Name": "Siddharth Kumar Singh",
        "Roll No.": "19817840",
        "Company Name": "Involead",
        "Profile": "Data Scientist",
        "Branch": "DualA-ECO",
        "ctc": "1250000.0",
        "companyID": "1962"
    },
    {
        "Name": "Sakshi Shashank Pachghare",
        "Roll No.": "19817745",
        "Company Name": "Dolat Capital",
        "Profile": "Quantitative Strategist",
        "Branch": "DualA-MTH",
        "ctc": "2700000.0",
        "companyID": "2178"
    },
    {
        "Name": "Shefnaan Fahad Sheikh",
        "Roll No.": "19807799",
        "Company Name": "AuxoAI",
        "Profile": "AI Engineer",
        "Branch": "DualA-AE",
        "ctc": "2576936.0",
        "companyID": "2111"
    },
    {
        "Name": "Devesh Pandey",
        "Roll No.": "22105024",
        "Company Name": "Renishaw Metrology ",
        "Profile": "Graduate Software Engineer",
        "Branch": "MT-ME",
        "ctc": "1235000.0",
        "companyID": "1993"
    },
    {
        "Name": "Himanshu Shekhar Das",
        "Roll No.": "19817380",
        "Company Name": "Kivi Capital",
        "Profile": "Quant Developer",
        "Branch": "DualA-MTH",
        "ctc": "4500000.0",
        "companyID": "2147"
    },
    {
        "Name": "Boodidha Surya Vamshi Reddy",
        "Roll No.": "19817242",
        "Company Name": "NMTronics India Private Limited",
        "Profile": "Robotics Engineer \u2013 Robotic Stack",
        "Branch": "DualA-PHY",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Ambuja Budakoti",
        "Roll No.": "19807112",
        "Company Name": "Sprinklr",
        "Profile": "Product Analyst",
        "Branch": "DualB-SEE",
        "ctc": "1500000.0",
        "companyID": "2023"
    },
    {
        "Name": "Prateesh Awasthi",
        "Roll No.": "19807636",
        "Company Name": "Sprinklr",
        "Profile": "Data Scientist",
        "Branch": "DualA-ME",
        "ctc": "1800000.0",
        "companyID": "2024"
    },
    {
        "Name": "Amit Yadav",
        "Roll No.": "19807119",
        "Company Name": "Deutsche India Private Limited",
        "Profile": "Graduate Analyst",
        "Branch": "DualA-ME",
        "ctc": "1963000.0",
        "companyID": "1967"
    },
    {
        "Name": "Aditya Prakash",
        "Roll No.": "19807065",
        "Company Name": "NMTronics India Private Limited",
        "Profile": "Robotics Engineer - Hardware",
        "Branch": "DualA-AE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Nitish Kumar",
        "Roll No.": "19807573",
        "Company Name": "Taiwan Semiconductor Manufacturing Company",
        "Profile": "Software",
        "Branch": "DualA-EE",
        "ctc": "716729.0",
        "companyID": "2069"
    },
    {
        "Name": "Nibir Baruah",
        "Roll No.": "19807545",
        "Company Name": "Quantbox Research",
        "Profile": "Core Engineering Analyst - Bangalore",
        "Branch": "DualA-CSE",
        "ctc": "10000000.0",
        "companyID": "1973"
    },
    {
        "Name": "Sahil Maurya",
        "Roll No.": "19807738",
        "Company Name": "Centific Global Solutions Inc",
        "Profile": "JUNIOR AI ENGINEER",
        "Branch": "DualA-EE",
        "ctc": "1200000.0",
        "companyID": "-1"
    },
    {
        "Name": "Shubhi Kant",
        "Roll No.": "19807836",
        "Company Name": "Accenture Japan",
        "Profile": "Data Scientist",
        "Branch": "DualA-CE",
        "ctc": "1000000.0",
        "companyID": "1914"
    },
    {
        "Name": "Samarth Sachan",
        "Roll No.": "19807749",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "Graduate Mechatronics Engineering Trainee",
        "Branch": "DualA-ME",
        "ctc": "2502000.0",
        "companyID": "2175"
    },
    {
        "Name": "Vinoba Pandey",
        "Roll No.": "19807974",
        "Company Name": "Bajaj Electricals",
        "Profile": "Graduate Engineer Trainee",
        "Branch": "DualA-ME",
        "ctc": "1500000.0",
        "companyID": "2517"
    },
    {
        "Name": "Tushar Kumar",
        "Roll No.": "19807916",
        "Company Name": "CapitalOne",
        "Profile": "Software Engineer",
        "Branch": "DualA-ME",
        "ctc": "2850000.0",
        "companyID": "2029"
    },
    {
        "Name": "Anshuman Singh",
        "Roll No.": "19816161",
        "Company Name": "C3iHub (IHub NTIHAC Foundation), IIT Kanpur",
        "Profile": "Software Development Engineer - SOC",
        "Branch": "DualB-ECO",
        "ctc": "2800000.0",
        "companyID": "2488"
    },
    {
        "Name": "Uma Singh",
        "Roll No.": "19807922",
        "Company Name": "Bajaj Auto Limited & Chetak Technology Limited",
        "Profile": "GTE24",
        "Branch": "DualA-ME",
        "ctc": "2174000.0",
        "companyID": "1958"
    },
    {
        "Name": "Ajay Kumar",
        "Roll No.": "19817074",
        "Company Name": "Axtria",
        "Profile": "Analyst",
        "Branch": "DualA-PHY",
        "ctc": "1375000.0",
        "companyID": "2227"
    },
    {
        "Name": "Prarabdh",
        "Roll No.": "19817630",
        "Company Name": "Nation with Namo",
        "Profile": "Associate",
        "Branch": "DualA-ECO",
        "ctc": "1900000.0",
        "companyID": "1854"
    },
    {
        "Name": "Titiksha Upadhyay",
        "Roll No.": "19807912",
        "Company Name": "GKN AEROSPACE ENGINE SYSTEMS INDIA PVT LTD",
        "Profile": "Graduate",
        "Branch": "DualA-AE",
        "ctc": "950000.0",
        "companyID": "1773"
    },
    {
        "Name": "Prasanna Patil",
        "Roll No.": "200707",
        "Company Name": "Axxela Research & Analytics Private Limited",
        "Profile": "Trainee Analyst",
        "Branch": "BT-MSE",
        "ctc": "1410000.0",
        "companyID": "1821"
    },
    {
        "Name": "Kunal Aggarwal",
        "Roll No.": "19807447",
        "Company Name": "Intel",
        "Profile": "Software/ Hardware Engineer",
        "Branch": "DualA-EE",
        "ctc": "1977327.0",
        "companyID": "2039"
    },
    {
        "Name": "Kartikeya Raguvanshi",
        "Roll No.": "200494",
        "Company Name": "Microsoft India",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Sahil Aggarwal",
        "Roll No.": "200835",
        "Company Name": "Xion Multiventures Pvt Ltd",
        "Profile": "Trainee Research Analysis & Operation Support  ",
        "Branch": "BT-CE",
        "ctc": "1620000.0",
        "companyID": "1938"
    },
    {
        "Name": "Anushka Pal",
        "Roll No.": "200173",
        "Company Name": "HPCL",
        "Profile": "Officer- Engineering",
        "Branch": "BT-CE",
        "ctc": "1697000.0",
        "companyID": "2077"
    },
    {
        "Name": "Vipul Kumar Arora",
        "Roll No.": "201125",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Nithin Nallani",
        "Roll No.": "200616",
        "Company Name": "Jaguar Land rover India Limited",
        "Profile": "PIO-PPO",
        "Branch": "BT-ME",
        "ctc": "0.0",
        "companyID": "-1"
    },
    {
        "Name": "Mandar Yogesh Patil",
        "Roll No.": "200678",
        "Company Name": "Walmart Global Tech India",
        "Profile": "PIO-PPO",
        "Branch": "BT-MSE",
        "ctc": "0.0",
        "companyID": "-1"
    }
]'
# Parse the JSON into an R object (data frame)
parsed_data <- fromJSON(json_string)

# Convert the data frame to a tibble
tibble_data <- as_tibble(parsed_data)

# Print the tibble
print(tibble_data)